#include <stdio.h>
#include <math.h>

double bisez(double a, double b, double tol);
double f(double x);

int main() {

	double a = -2, b = 1, tol = 0.000000001, res;
	
	res = bisez(a, b, tol);
	
	printf("\n%f\n", res);

}

// Potete cambiare la funzione f modificando qui sotto

double f(double x) {

	return x * x * x;

}

double bisez(double a, double b, double tol) {
	
	double res, c;
	
	if (f(a) * f(b) > 0) {
		printf("\nErrore!\n");
		return 0;
	}
	
	if (f(a) == 0) {
		res = a;
		return res;
	}
	
	if (f(b) == 0) {
		res = b;
		return res;
	}
	
	c = (a+b) / 2;
	
	if (fabs(f(c)) < tol || fabs(b-a) < tol) {
		res = c;
		return res;
	}
	
	if (f(c) * f(b) < 0)
		res = bisez(c, b, tol);
	else
		res = bisez(a, c, tol);
		
	return res;

}