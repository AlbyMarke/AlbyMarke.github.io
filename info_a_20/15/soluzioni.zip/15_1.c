#include <stdio.h>
#define N 7

int tart(int n, int k);

int main() {

	int n, k;
   
   	for (n = 0; n <= N; n++) {
    	for (k = 0; k <= n; k++)
        	printf(" %5d", tart(n, k));
      	printf("\n");
   	}

	return 0;
}

int tart(int n, int k) {

	if (n < k || n < 0 || k < 0) {
    	printf("Errore\n");
        return 0;
     }
     
	if (k == 0  || k == n) /* casi base */
    	return 1;
     else
        return tart(n-1, k-1) + tart(n-1, k); /* chiamata ricorsiva */
} 

