#include <stdio.h>

int convert(int n);

int main(){
	printf("Decimal: 10--- binary: %d\n", convert(10));
	printf("Decimal: 1--- binary: %d\n", convert(1));
	printf("Decimal: 12--- binary: %d\n", convert(12));
	printf("Decimal: 21--- binary: %d\n", convert(21));

	return 0;
}

int convert(int n){
	int q,r;

	if(n==0)
		return 0;
	
	r = n%2;
	q = n/2;
	
	return convert(q)*10 + r;
}
	
	
