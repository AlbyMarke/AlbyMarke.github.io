#include <stdio.h>
#include <stdlib.h>
#include <string.h>
		
int f(char * x, char * y, int k);
int g(int i, char * a, char * b);
		
int main() {
	int i = 3;
		
	char x[] = "P", y[]  = "LO";
	i++;
	printf("%c", *x); 
	i = f( x, y, i-1 );
		
	return 0;
}

int f( char * x, char * y, int k ) {
	if( k ) {
		k=g(k,x,y);
	}
	return k+1;
}

int g(int i, char * a, char * b){
	int j;
	if(i%2==0)
		j=0;
	else
		j=1;	
	printf("%c", b[j]);
	i = f( a, b, i-1 );
	return i;
}