#include <stdio.h>
#include <stdlib.h>

#define N 10

typedef int TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista InsInTesta (Lista lista, TipoElem elem);
void VisualizzaLista(Lista lista);
Lista Eliminaiel(Lista lis, int i);

int main () {

	Lista lis = NULL;
	Elem * max;
	int i;
	
	for (i = N; i > 0; i--) 
		lis = InsInTesta(lis, i);
	
	VisualizzaLista(lis);
	printf("\n");	
	
	lis = Eliminaiel(lis, 3);
	
	VisualizzaLista(lis);
	printf("\n");	
	
}	

Lista InsInTesta (Lista lista, TipoElem elem) {
	Lista punt;
	punt = (Lista) malloc(sizeof(Elem));
	punt->info = elem;
	punt->prox = lista;		
	return punt;
}

void VisualizzaLista(Lista lista) {
    if (lista == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d\n ---> ", lista->info);
    	VisualizzaLista(lista->prox);
    }
}

Lista Eliminaiel(Lista lis, int i) {
	Lista aux, temp = lis;
	int j = 0;
	while ((temp != NULL) && (j < i)) {
		aux = temp;
		temp = temp->prox;
		free(aux);
		j++;
	}
	return temp;
}

