# include <stdio.h>
# include <string.h>
# define DIM 100 

int main() {

	char a[DIM], b[DIM]; 
	int len, contA, contB, i, k, si = 1;
	
	printf("Inserire prima parola: ");
	scanf("%s", a);
	printf("Inserire seconda parola: ");
	scanf("%s", b);
	
	// se lunghezza parole diversa allora non sono anagrammi
	len = strlen(a);
	if (len != strlen(b)) 
        si=0;
        
    //per ogni a[i] in a (escluso il \0)
	for (i = 0; i < len && si==1; i++ ) {  
		contA = 0; contB = 0;
		
		//scandisco le stringhe
		for (k = 0; k < len; k++ ) {  
				
				//conto le occorrenze di a[i] in a
      			if (a[k] == a[i])
        			contA++; 
        		
        		//e le occorrenze di a[i] in b
      			if (b[k] == a[i])
        				contB++; 
    		}
    		if (contA != contB) 
				si = 0;
	}
	printf("%d\n", si); 
}
