#include <stdio.h>
#include <string.h>
#define DIM 160


int main(){

	char messaggio[DIM + 1];
	char cifrato[DIM + 1];

	int lungh;
	int chiave;
	int i;

	printf("Inserire un messaggio: ");

	gets(messaggio);

	lungh = strlen(messaggio);

	do {

    	printf("Inserire una chiave: ");
    	scanf("%d", &chiave);
    
	} while ( chiave < 1 || chiave > 25 );
    
    // serve ad eliminare dall'input il carattere \n lasciato dalla scanf
    fflush(stdin);

	// cifra messaggio 
	for (i = 0; i <= lungh; i++) {
    	if (messaggio[i] > 96 && messaggio[i] < 123) {
        	cifrato[i] = (messaggio[i] - 97 + chiave) % 26 + 97;
    	} else
        	cifrato[i] = messaggio[i];

	}

	printf("Messaggio cifrato: ");
	printf("%s\n",cifrato);

	printf("Inserire un messaggio cifrato: ");

	gets(cifrato);
	
	lungh = strlen(cifrato);

	// decifra messaggio
	for (i = 0; i <= lungh; i++) {
    	if (cifrato[i] > 96 && cifrato[i] < 123)
        	messaggio[i] = (cifrato[i] - 97 + (26 - chiave) ) % 26 + 97;
    	else
        	messaggio[i] = cifrato[i];

	}

	printf("Messaggio in chiaro: ");
	printf("%s\n",messaggio);

}
