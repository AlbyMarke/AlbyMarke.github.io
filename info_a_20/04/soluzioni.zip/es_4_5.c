#include <stdio.h>
#include <string.h>
#define N 100

int main( ) {

    char str1[N], str2[N];
    int i, j, lun1, lun2, compatibili;
    
    printf("Inserire due stringhe\n");
    scanf("%s", str1);
    scanf("%s", str2);
	lun1=strlen(str1); 
    lun2=strlen(str2); 
       
    if(lun1!=lun2)
		printf("Stringhe non compatibili");
    else {
		
		// codice che verifica
        compatibili = 1;
       	for(i = 1; i < lun1  && compatibili; i = i+2) {
			if(str1[i] != str2[i])
	    		compatibili = 0;
        }
        if(compatibili == 1)
			printf("str1 e str2 direttamente compatibili.\n");                
        else
			printf("str1 e str2 non direttamente compatibili.\n");                

		compatibili = 1;
		for(i = 0; i < lun1 && compatibili; i = i+2) {
			if(str1[i] != str2[i])
				compatibili = 0;
        }
        if(compatibili == 1)
			printf("str1 e str2 inversamente compatibili.\n");       
        else
			printf("str1 e str2 non inversamente compatibili.\n");       

    }
} 
