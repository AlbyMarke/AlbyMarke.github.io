#include <stdio.h>
#define DIM 200 

int main () {
 
	char str1[DIM], str2[DIM], strTot[2*DIM];
	int i,j; 
	
	printf("Inserisci la prima stringa:\n"); 
	scanf("%s", str1);
	printf("Inserisci la seconda stringa:\n"); 
	scanf("%s", str2);
	
	for (i = 0; str1[i] != '\0'; i++)
		strTot[i] = str1[i];
		
	/* nota: i rappresenta il numero di caratteri copiati da str1 a strTot */
	for (j = 0; str2[j]!= '\0';j++) /* accodo str2 a str1 */ 
		strTot[i+j] = str2[j];
		 
	strTot[i+j] = '\0';
	 
	printf("%s\n", strTot); 
} 
