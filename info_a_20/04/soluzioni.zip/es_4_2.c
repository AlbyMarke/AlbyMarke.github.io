#include<stdio.h>
#include<string.h> 
#define DIM 100 

int main() {
 
	char stringa[DIM];
	 
	int contatore = 0, i, quanti = 0;
	 
	printf("Inserisci la stringa:\n"); 
	scanf("%s", stringa); 
	
	contatore = strlen(stringa);
	
	for(i = 0; i < contatore / 2; i++) 
		if (stringa[i] == stringa[contatore - i - 1])
			quanti++;
			
	if(quanti == contatore / 2) 
		printf("Palindromo\n");
	else
		printf("Non Palindromo\n");
} 
