/*
Dato un numero positivo $Q$, scrivere la sua rappresentazione in binario naturale, 
indicando anche il minimo numero di bit utilizzato. 
Il programma deve esibire un comportamento come nell'esempio seguente: 

Input: 19 in decimale. 
Output: con 5 bit  =  10011 in binario.
*/
#include<stdio.h>
int main(){
	int q,n,d,i;

	do{
		printf("Inserire intero positivo\n");
		scanf("%d",&q);
	}while(q<=0);

	d=1;
	n=0;
	/* d è la minima potenza di 2 maggiore di q. 
	n è l'esponente per ottenere d, e quindi è il numero minimo di bit per 
	rappresentare q.*/
	while(d<=q){
		n++;
		d=d*2;
	}
	printf("Numero min di bit: %d\n",n);

	i=n-1;
	while(i>=0){
		d=d/2;
		if(q>=d){
			printf("1");
			q=q-d;
		}else{
			printf("0");
		}
		i--;
	}
	printf("\n");

	return 0;
}
