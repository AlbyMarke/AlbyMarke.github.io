#include <stdio.h>
#include <stdlib.h>

/*
Scrivere un programma, che dati tre interi positivi, valuti se possono essere i lati di un triangolo. Nel caso di risposta positiva, si comunichi anche il tipo di triangolo (scaleno, isoscele, equilatero, rettangolo).
*/

int main(int argc, char* argv[]){
  int a,b,c;
  int somma_a, somma_b, somma_c;
  int diff_a, diff_b, diff_c;
  int is_triangolo;
  int ipotenusa, somma;

  printf("Introdurre tre interi positivi\n");
  scanf("%d",&a);
  scanf("%d",&b);
  scanf("%d",&c);

  /* somma maggiore del terzo*/
  somma_a = b+c > a;
  somma_b = a+c > b;
  somma_c = a+b > c;

  /* differenza minore del terzo*/
  diff_a = abs(b-c) < a;
  diff_b = abs(a-c) < b;
  diff_c = abs(a-b) < c;

  is_triangolo = somma_a && somma_b && somma_c && diff_a && diff_b && diff_c;

  if (!is_triangolo)
    printf("I tre numeri non sono i lati di un triangolo\n");
  else
    printf("I tre numberi sono i lati di un triangolo\n");

  if (is_triangolo) {
      if (a == b && b == c)
          printf(" equilatero\n");
      else {
          if (a != b && a!= c && c != b)
              printf(" scaleno\n");
          else
              printf(" isoscele\n");
          // controllo se è rettangolo
          if (a >= b && a >= c) {
              ipotenusa = a * a;
              somma = b*b + c*c;
          }
          if (b > a && b >= c) {
              ipotenusa = b * b;
              somma = a*a + c*c;
          }
          if (c >= a && c >= b) {
              ipotenusa = c * c;
              somma = a*a + b*b;
          }
          if (ipotenusa == somma)
              printf(" rettangolo\n");
      }

  }

  return 0;
}
