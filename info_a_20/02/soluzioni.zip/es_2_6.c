#include <stdio.h>

/*
Scrivere un programma che dato un numero N > 0 di valori da inserire da tastiera, stampi a video il massimo della sequenza inserita e la posizione in cui tale valore è stato inserito. Supponiamo, per semplicità, che non ci siano duplicati.
*/

void main(){
  int n, val, max_val, max_pos, counter;

  printf("Inserire numero di valori\n");
  scanf("%d", &n);

  counter = 1;

  if(n>0){
    printf("Inserire il prossimo valore\n");
    scanf("%d", &val);

    max_pos = counter;
    max_val = val;

    while (counter < n){
      printf("Inserire il prossimo valore\n");
      scanf("%d", &val);

      counter = counter + 1;

      if(val > max_val){
        max_val = val;
        max_pos = counter;
      }
    }
    printf("massimo valore= %d, posizione=%d\n",max_val, max_pos);
  }else{
    printf("il numero di valori deve essere > 0\n");
  }
}
