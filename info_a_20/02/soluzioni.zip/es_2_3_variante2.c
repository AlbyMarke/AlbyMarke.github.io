#include <stdio.h>

/*
Scrivere un programma che, letti tre numeri interi a, b, c dallo standard input, stampi a terminale la sequenza dei tre numeri in ordine monotono non decrescente.
*/

int main(int argc, char* argv[]){

  int a,b,c,temp;

  printf("Introdurre tre numeri interi\n");
  scanf("%d %d %d", &a, &b, &c);

  if(a>b){
    temp = b;
    b = a;
    a = temp;
  }
  if(a>c){
    temp = c;
    c = a;
    a = temp;
  }
  if(b>c){
    temp = c;
    c = b;
    b = temp;
  }
  printf("Ordine: %d, %d, %d\n", a,b,c);
  return 0;
}
