#include <stdio.h>

/*
Scrivere un programma che, letti tre numeri interi a, b, c dallo standard input, stampi a terminale la sequenza dei tre numeri in ordine monotono non decrescente.
*/

int main(int argc, char* argv[]){

  int a,b,c;

  printf("Introdurre tre numeri interi:\n");
  scanf("%d %d %d", &a, &b, &c);

  if(a<b){
    if(b<c){
      printf("ordine: %d, %d, %d\n",a,b,c);
    }else{
      if(a<c){
        printf("ordine: %d, %d, %d\n",a,c,b);
      }else{
        printf("ordine: %d, %d, %d\n",c,a,b);
      }
    }
  }else{
    if(b<c){
      if(a<c){
        printf("ordine: %d, %d, %d\n",b,a,c);
      }else{
        printf("ordine: %d, %d, %d\n",b,c,a);
      }
    }else{
      printf("ordine: %d, %d, %d\n",c,b,a);
    }
  }

  return 0;
}
