/*
	Scrivere un programma che, dati a e b interi positivi, 
	visualizza un rettagolo formato da * di dimensioni axb.
*/
#include<stdio.h>
int main(){
	int a,b,r,c;

	do{
		scanf("%d %d",&a,&b);
	}while(a<=0 || b<=0);

	for (r=0;r<a;r++){
		for(c=0;c<b;c++){
			if(r==0 || r==a-1 || c==0 || c==b-1)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}

	return 0;
}