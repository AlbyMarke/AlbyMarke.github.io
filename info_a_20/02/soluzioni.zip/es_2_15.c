/*
	Si scriva un programma  per calcolare il minimo comune multiplo (MCM)
	di due numeri interi positivi. (Dati due numeri interi $x$ e $y$, il minimo comune multiplo
	e' il piu' piccolo numero $M$ che è divisibile (con resto pari a zero) sia per $x$ che per $y$.
*/
#include<stdio.h>
int main(){
	int x,y;
	int max,min;
	int i,flag,mcm;

	do{
		scanf("%d %d",&x,&y);
	}while(x<=0||y<=0);

	if(x>y){
		max=x;
		min=y;
	}else{
		max=y;
		min=x;
	}

	i=1;
	mcm=0;
	flag=0;

	while(flag==0){
		mcm = i*max;
		if(mcm%min==0){
			flag=1;
		}else{
			i++;
		}
	}

	printf("il MCM tra %d e %d e' %d\n",x,y,mcm);
	return 0;
}