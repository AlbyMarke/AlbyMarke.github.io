/*
	Scrivere un programma per la rappresentazione del triangolo di Floyd.
	Il triangolo di Floyd è un triangolo che contiene numeri naturali, definito 
	riempiendo le righe del triangolo con numeri consecutivi, partendo da 1 
	nell'angolo in alto a sinistra. 
	Il programma riceve da tastiera un numero intero $N$, e visualizza le prime $N$ 
	righe del triangolo di Floyd.
*/

#include<stdio.h>
int main(){
	int n;
	int r,c;
	int i;

	do{
		printf("Inserire il numero di righe del triangolo\n");
		scanf("%d",&n);
	}while(n<=0);

	i=1;

	for(r=1;r<n;r++){
		for(c=0;c<r;c++){
			printf("%d ",i);
			i++;
		}
		printf("\n");
	}
	return 0;
}