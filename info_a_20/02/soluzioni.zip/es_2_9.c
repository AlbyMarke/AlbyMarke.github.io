#include<stdio.h>

int main() {
	int n, primo =1, i = 2;
	scanf("%d", &n);

	while(i <= n/2 && primo == 1) {
		if(n%i==0)
			primo = 0;
		i++;
	}

	printf("\n%d ", n);
	if(primo == 0)
		printf("NON ");
	printf("e' primo ");
}