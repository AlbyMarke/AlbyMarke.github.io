#include <stdio.h>

/*
Scrivere un programma che, dati tre interi positivi, visualizzi 1 se sono una terna pitagorica, 0 altrimenti.
*/

int main(int argc, char * argv[]){
  int x,y,z,terna;

  printf("Introdurre tre interi positivi:\n");
  scanf("%d %d %d", &x, &y, &z);

  terna = 0;

  if(x > y && x > z){
    if(x*x == y*y + z*z)
      terna = 1;
  }else{
    if(y > x && y > z){
      if(y*y == x*x + z*z)
        terna = 1;
    }else
      if(z*z == x*x + y*y)
        terna = 1;
  }

  printf("Risultato: %d\n", terna);

  return 0;
}
