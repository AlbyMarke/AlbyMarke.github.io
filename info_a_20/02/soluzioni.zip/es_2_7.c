#include <stdio.h>

/*
Scrivere un programma che, letto un numero intero positivo dallo standard input, visualizzi a terminale il quadrato del numero stesso facendo uso soltanto di operazioni di somma. (Il quadrato di ogni numero intero positivo N può essere costruito sommando tra loro i primi N numeri dispari.)
*/

int main(){
  int n,res,i;

  printf("Introdurre un numero intero positivo\n");
  scanf("%d",&n);

  res = 0;
  i = 0;

  while(i<=n+n){
    if(i%2!=0){
      res = res + i;
    }
    i = i + 1;
  }

  printf("result=%d\n",res);
  return 0;
}
