#include <stdio.h>

/*
Si scriva un programma che legge una sequenza di interi positivi (la sequenza termina quando viene inserito il valore -1), conta il numero complessivo dei numeri che sono multipli di 3, di 5 oppure di 7 compresi nella sequenza e stampa questo valore. Per esempio, nel caso la sequenza in ingresso fosse 4 8 12 15 14 8, il programma dovrebbe stampare il valore 3.
*/

int main(){
    int x, counter, flag;

    printf("Inserire il primo valore\n");
    scanf("%d", &x);

    counter = 0;
    flag = 0;

    while(x != -1){
      if(x%3 == 0){
        counter = counter + 1;
        flag = 1;
      }else{
        if(flag == 0 && x%5 == 0){
          counter = counter + 1;
          flag = 1;
        }else{
          if(flag == 0 && x%7 == 0){
            counter = counter + 1;
            flag = 1;
          }
        }
      }
      flag = 0;
      printf("Inserire il prossimo valore\n");
      scanf("%d", &x);
    }
    printf("sequenza in input terminata\n risultato=%d\n",counter);
    return 0;
}

/*
soluzione più semplice
int main(){
    int x, counter;

    printf("Inserire il primo valore\n");
    scanf("%d", &x);

    counter = 0;

    while(x != -1){
      if(x%3==0 || x%5==0 || x%7==0){
        counter = counter +1;
      }
      printf("Inserire il prossimo valore\n");
      scanf("%d", &x);
    }
    printf("sequenza in input terminata\n risultato=%d",counter);
    return 0;
}
*/
