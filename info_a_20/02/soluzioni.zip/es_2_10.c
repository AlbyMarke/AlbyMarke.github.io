/*Scrivere un programma che, dati due numeri interi positivi (li chiede fino a
quando non sono tali), visualizza il MCD (massimo tra i divisori comuni) tra due numeri.*/
#include<stdio.h>

int main(){
	int x,y;
	int div,mcd;

	do{
		printf("Introduci primo numero:\n");
		scanf("%d",&x);
	}while(x<=0);

	do{
		printf("Introduci secondo numero:\n");
		scanf("%d",&y);
	}while(y<=0);

	div = 1;
	mcd = 1;

	while(div<=x && div<=y){
		if(x%div==0 && y%div==0){
			mcd=div;
		}
		div++;
	}

	printf("MCD: %d\n",mcd);


	return 0;
}
