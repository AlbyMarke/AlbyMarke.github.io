#include <stdio.h>

/*
Dato un numero intero positivo, scrivere un programma che visualizzi il suo numero di cifre.
*/

void main(){
  int n,i;

  printf("Introdurre un numer intero positivo\n");
  scanf("%d", &n);

  i = 0;
  while(n>0){
    n = n/10;
    i = i+1;
  }

  printf("cifre: %d\n",i);
}
