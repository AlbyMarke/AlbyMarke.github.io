/*	 Due numeri m e n sono amicali se la somma dei divisori di m e' 
uguale ad n, e viceversa (per esempio 220 e 284, 1184 e 1210, 2620 e 2924, 
5020 e 5564, 6232 e 6368, 17296 e 18416). 
Scrivere un programma che, ricevuti in ingresso due numeri interi, 
visualizza 1 se i numeri sono amicali, 0 altrimenti.*/

#include <stdio.h>

void main(){

int n,m;
int sum_n, sum_m;
int i;

scanf("%d",&n);
scanf("%d",&m);

printf("Divisori di %d: ",n);
sum_n = 0;
for (i = 1; i <= n / 2; i++) {
    if (n % i == 0) {
        printf("%d,",i);
        sum_n += i;
    }
}
printf("\n");

printf("Divisori di %d: ",m);
sum_m = 0;
for (i = 1; i <= m / 2; i++) {
    if (m % i == 0) {
        printf("%d,",i);
        sum_m += i;
    }
}
printf("\n");

if (sum_n == m && sum_m == n)
    printf("1\n");
else
    printf("0\n");

}