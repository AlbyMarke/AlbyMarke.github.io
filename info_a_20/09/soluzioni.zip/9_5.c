/*Data N costante predefinita, scrivere una funzione
void f(int v[], int x)
che, preso in input il vettore v di lunghezza N , con x < N , eleva al quadrato ogni
elemento della sotto-sequenza che inizia all’x-esimo elemento di v e viene terminata alla
prima occorrenza di uno 0.
Utilizzare una funzione ausiliaria void subpow(int v[], int len).
Esempio: Input: v = [1, 2, 3, 1, 2, 0, 2, 3, 0], x = 3. Output: v = [1, 2, 9, 1, 4, 0, 2, 3, 0].*/
#include<stdio.h>
#define N 10

void f(int [],int);
void subpow(int [],int);

void main(){
  int v[N]={1,2,3,1,2,0,2,3,0,2};
  int i,x=3;

  f(v,x);

  //print
  printf("Risultato: ");
  for(i=0;i<N;i++){
    printf(" %d",v[i]);
  }
}

void f(int v[], int x){
  int i,len=0;
  for(i=x-1;i<N;i++){
    if(v[i]==0)
      break;
    len++;
  }
  subpow(v+(x-1),len);
}

void subpow(int v[], int len){
  int i;
  for(i=0;i<len;i++){
    v[i] = v[i]*v[i];
  }
}
