// Scrivere una funzione che riceve in ingresso due stringhe lunghe al più N (con N definito come costante in una macro) e modifica la prima stringa togliendo da essa tutte le occorrenze di caratteri presenti nella seconda. La stringa risultante non deve avere buchi.
// Gracchiare, atte --- Grcchir
#include<stdio.h>
#include<string.h>
#define N 100

void f(char [], char []);
void rimuovi(char [], char);

int main(){
  char str1[N], str2[N];

  printf("Inserisci la prima stringa\n");
  scanf("%s", str1);
  printf("Inserisci la seconda stringa\n");
  scanf("%s", str2);

  f(str1, str2);
  printf("nuova stringa: %s\n", str1);

  return 0;
}

void f(char str1[], char str2[]){
  int i;
  for (i=0; str2[i]!='\0'; i++){
    rimuovi(str1, str2[i]);
  }
}

void rimuovi(char str[], char c){
  int i,j;
  printf("str: %s, c: %c\n", str,c);
  for(i=0;str[i]!='\0';i++){
      if(str[i]==c){
        for(j=1;str[i+j]!='\0';j++)
          str[i+j-1]=str[i+j];
        str[i+j-1]='\0';
      }
  }
}
