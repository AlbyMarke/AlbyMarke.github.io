/* Scrivere una funzione che, dato un vettore di interi v di dimensione N
(costante predefinita), calcoli la somma degli elementi pari, e la somma degli elementi dispari.
Si utilizzi una funzione
void update(int *p, int *d, int val)
per aggiornare la somma dei numeri pari p e la somma dei dispari d.*/
#include <stdio.h>
#define N 5

void f(int [], int *, int *);
void update(int *, int *, int);
int pari(int);

void main(){
  int v[N]= {1,2,3,4,5};
  int *p,*d,a,b;

  // ATTENZIONE!
  p=&a;
  d=&b;
  *p=0;
  *d=0;

  f(v,p,d);

  printf("pari: %d, dispari: %d\n",*p,*d);
}

void f(int v[], int *p, int *d){
  int i;
  for(i=0;i<N;i++){
    update(p,d,v[i]);
  }
}

void update(int *p, int *d, int val){
  if(pari(val)){
    (*p)+=val;
  }else{
    (*d)+=val;
  }
}

// ritorna 1 se pari, 0 altrimenti
int pari(int n){
  if (n%2==0)
    return 1;
  return 0;
}
