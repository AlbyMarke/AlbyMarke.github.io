//Scrivere un programma che letta una sequenza di $N$ numeri complessi dallo standard input (rappresentati con parte reale e parte immaginaria) stampi video la sequenza ordinata in maniera crescente secondo il valore dei loro moduli.
#include <stdio.h>
#include <math.h>
#define MAX_LEN 100

typedef struct{
  float re;
  float im;
} complex;

void scambio(complex *p1, complex *p2);
float modulo(complex c);
int cmp(complex c1, complex c2);
void ordina(int N, complex v_in[], complex v_out[]);

complex leggi_complesso();
void stampa_vec_complessi(complex [], int);

int main(){
  complex v_in[MAX_LEN], v_out[MAX_LEN];
  int i,N;

  do{
    printf("Introduci N (massimo possibile: %d)", MAX_LEN);
    scanf("%d",&N);
  }while(N>MAX_LEN);

  for(i=0;i<N;i++){
    v_in[i] = leggi_complesso();
  }

  ordina(N, v_in, v_out);

  stampa_vec_complessi(v_out, N);

  return 0;
}

complex costruisci_complesso(float r, float i){
  complex c;
  c.re = r;
  c.im = i;
  return c;
}

complex leggi_complesso(){
  complex c;
  printf("parte reale:\n");
  scanf("%f", &(c.re));
  printf("parte immaginaria:\n");
  scanf("%f", &(c.im));
  return c;
}

void stampa_vec_complessi(complex v[],int N){
  int i;
  for(i=0;i<N;i++){
    printf("re: %f, im: %f\n", v[i].re, v[i].im);
  }
}

void scambio(complex *p1, complex *p2){
  complex aux;
  aux = *p1;
  *p1 = *p2;
  *p2 = aux;
}

float modulo(complex x){
  float res;
  res=sqrt((x.re*x.re)+(x.im*x.im));
  return res;
}

/* c1>c2--> ritorna 1
c1<c2--> ritorna -1
c1==c2--> ritorna 0 */
int cmp(complex c1, complex c2){
  float m1,m2;
  m1=modulo(c1);
  m2=modulo(c2);

  if(m1>m2)
    return 1;
  else
    if(m1<m2)
      return -1;
    else
      return 0;
}

void ordina(int N, complex v_in[], complex v_out[]){
  int i,j;

  // copio v_in in v_out per non modificare il vettore v_in
  for(i=0; i<N;i++){
    v_out[i]=v_in[i];
  }

  for(i=0;i<N-1;i++){
    for(j=0;j<N-i-1;j++){
      if(cmp(v_out[j],v_out[j+1])>0){
        scambio(&v_out[j],&v_out[j+1]);
      }
    }
  }
}
