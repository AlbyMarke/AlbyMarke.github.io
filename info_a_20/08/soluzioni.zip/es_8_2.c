#include<stdio.h>
#define MAX_GRADO 8
 
int main(){
  int g1, g2, g3, p1[MAX_GRADO+1], p2[MAX_GRADO+1], p3[MAX_GRADO*2+1], i, j, x, val, pot;
 
  do{
    scanf("%d", &g1);
  } while(g1 < 0 || g1 > MAX_GRADO);
  for(i = 0; i <= g1; i++){
    scanf("%d", &p1[i]);
  }

  do{
    scanf("%d", &g2);
  }while(g2 < 0 || g2 > MAX_GRADO);
  for(i = 0; i <= g2; i++){
    scanf("%d", &p2[i]);
  }
  
  g3 = g1+g2;

  for(i = 0; i <= g3; i++)
    p3[i] = 0;
  
  for(i = 0; i <= g1; i++)
    for(j = 0; j <= g2; j++)
      p3[i+j] = p3[i+j]+p1[i]*p2[j];
 
  for(i = 0; i <= g3; i++)
    printf("%d ", p3[i]);
  printf("\n");
  
  scanf("%d",&x);
  
  val = 0;
  pot = 1;
  for(i = 0; i <= g3; i++){
    val = val+p3[i]*pot;
    pot = pot*x;
  }
 
  printf("%d\n", val);
  
}