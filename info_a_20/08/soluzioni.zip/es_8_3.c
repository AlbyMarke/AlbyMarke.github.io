#include <stdio.h>
#define N 10

int main() {

	int m[N][N],i,j,cont=0,max=0;            

	// leggo matrice
	for(i=0;i<N;i++)
		for(j=0;j<N;j++)
        	scanf("%d",&m[i][j]);
  
	//righe
  	for(i=0;i<N;i++){
    	cont=0;
      	for(j=1;j<N;j++) {
        	if(m[i][j]==m[i][j-1]){
           		cont++;
           		if(cont>max)
              		max=cont; 
         	} else {
           		cont=0;
         	}
      	}                            
  	}

	//colonne
  	for(i=0;i<N;i++){
    	cont=0;
    	for(j=1;j<N;j++){ 
        	if(m[j][i]==m[j-1][i]){
          		cont++;
          		if(cont>max)
            		max=cont; 
        	} else {
          		cont=0;
        	}                 
      	}
	}

	//diagonali
  
	//diagonali da sx a dx parte sopra    
	for(i=0;i<N;i++){
    	cont=0;
    	for(j=1;j<N-i;j++){ 
        	if(m[j][j+i]==m[j-1][j-1+i]){
        		cont++;
          		if(cont>max)
            		max=cont; 
        	} else {
          		cont=0;                 
        	}
      	}
  	}
  
  	//diagonali da sx a dx parte sotto
  	for(i=0;i<N;i++){
      	cont=0;
      	for(j=1;j<N-i;j++) { 
        	if(m[j+i][j]==m[j-1+i][j-1]){
          		cont++;
          		if(cont>max)
            		max=cont; 
        	} else {
          		cont=0;                 
        	}
      	}
  	}
  
  	//diagonali da dx a sx parte sopra 
  	for(i=0;i<N;i++){
      	cont=0;
      	for(j=1;j<N-i;j++){ 
        	if(m[N-1-j][j+i]==m[N-1-(j-1)][j-1+i]){
          		cont++;
          		if(cont>max)
            		max=cont; 
        	} else {
          		cont=0;                 
        	}
      	}
  	}
  
  	//diagonali da dx a sx parte sotto 
  	for(i=0;i<N;i++){
      	cont=0;
      	for(j=1;j<N-i;j++){ 
        	if(m[j+i][N-1-j]==m[j-1+i][N-1-(j-1)]){
          		cont++;
          		if(cont>max)
            		max=cont; 
        	} else {
          		cont=0;                 
        	}
      	}
  	}
  
  	printf("Risultato: %d\n",max+1);
} 
