/*
Si scriva una fuzione
int f(int M[][N], int A[])
che riceve in ingresso una matrice quadrata N×N (con N costante predefinita con l’istruzione #define N ) di interi positivi M ed un array A di dimensione N . La funzione copia in A (riempiendo a da sinistra a destra senza lasciare buchi) gli elementi della diagonale principale di M che sono presenti anche nel triangolo al di sopra della diagonale principale (a eventuali caselle non usate in fondo ad A dovrà essere assegnato il valore -1) e restituisce il numero di elementi copiati.
*/
#include <stdio.h>
#define N 5

int f(int [][N], int []);
int check(int [][N], int);

int main(){
  int M[N][N] = {{16,0,3,0,0},{3,1,1,2,1},{0,0,13,0,0},{0,7,2,3,2},{0,5,1,6,4}};
  int v[N], res, i;

  res = f(M,v);
  printf("num elementi copiati: %d\nVettore: ", res);

  for(i=0;i<N;i++){
    printf("%d ",v[i]);
  }
}

int f(int m[][N], int v[]){
  int i,tot=0,j=0;
    
  for(i=0;i<N;i++){
    if (check(m,m[i][i])){
      v[j]=m[i][i];
      j++;
      tot++;
    }
  }
  for(i=j;i<N;i++){
      v[i]=-1;
  }
  return tot;
}

// restituisce 1 se l'elemento è presente al di sopra della diagonale principale
// m, 0 altrimenti
int check(int m[][N], int n){
  int i,j,found=0;

  for(i=0;i<N && found!=1;i++){
    for(j=i+1;j<N && found!=1;j++){
      if(m[i][j]==n)
        found=1;
    }
  }
  return found;
}
