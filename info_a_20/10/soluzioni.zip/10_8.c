#include <stdio.h>
#define N 10

int maxArray(int *array, int n);
 
int main() {
	int test[N] = {2, 3, 9, 2, 13, 4, 34, 2, 9, 5};
	
	printf("Max = %d \n", maxArray(test,N));
	
	return 0; 
 }
 
int maxArray(int *array, int n) {
	int maxsub;
	if (n == 1) 
		return array[0];
	if (n >= 2) {
    	maxsub = maxArray(&array[1],n-1);
	    if (array[0] > maxsub) 
     		return array[0];
	    else 
     		return maxsub;
   	}
   	return -1;  /* non raggiungibile */
}

