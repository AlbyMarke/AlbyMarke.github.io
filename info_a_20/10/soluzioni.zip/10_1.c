// Scrivere una funzione f che riceve una matrice NxN di interi e conta quanti elementi sono circondati solo da numeri pari.
#include <stdio.h>
#define N 4

int f(int [][N]);
void read_square_matrix(int [][N]);
void print_square_matrix(int [][N]);

int main(){
  int m[N][N];

  read_square_matrix(m);
  print_square_matrix(m);

  printf("numero di elementi circondati da soli numeri pari= %d\n", f(m));

  return 0;
}

void read_square_matrix(int m[][N]){
  int r,c;
  printf("Inserire matrice\n");
  for (r=0; r<N; r++)
    for (c=0; c<N;c++)
      scanf("%d", &m[r][c]);
  printf("\n");
}

void print_square_matrix(int m[][N]){
  printf("Inserted matrix:\n");
  int r,c;
  for (r=0;r<N;r++){
    for (c=0;c<N;c++)
      printf(" %d ", m[r][c]);
    printf("\n");
  }
}

/* questa e' la funzione richiesta dall'esercizio*/
int f(int m[][N]){
  int i, j, r, c, tot=0, cur;

  for(i=0; i<N; i++){
    for(j=0; j<N; j++){
      // numero di elementi pari o "esterni" che circondano l'elemento (i,j)
      cur=0;
      for(r=i-1; r<=i+1; r++){
        for(c=j-1; c<=j+1; c++){
          if(r!=i || c!=j){
            //elementi sul bordo
            if(r<0 || r<0 || r>=N || c>=N){
              cur++;
            }else{
              // elementi pari
              if(m[r][c]%2==0){
                cur++;
              }
            }
          }
        }
      }
      // fine del for che controlla gli elementi attorno ad (i,j)
      if(cur==8){
        printf("(%d,%d) ",i,j);
        tot++;
      }
    }
  }
  return tot;
}
