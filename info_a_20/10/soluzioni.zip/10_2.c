//Scrivere una funzione f che riceve una matrice NxN di interi e un vettore di interi di lunghezza N e restituisce 1 se esiste una riga o una colonna o una diagonale che contiene tutti gli elementi del vettore nello stesso ordine o in ordine inverso, 0 altrimenti.

#include <stdio.h>
#define N 3

int f(int [][N], int v[]);
void read_vector(int []);
void read_square_matrix(int [][N]);
void print_square_matrix(int [][N]);

int main(){
  int m[N][N];
  int v[N];

  printf("introdurre vettore di dimensione %d\n", N);
  read_vector(v);

  printf("introdurre matrice di interi %dx%d\n",N,N);
  read_square_matrix(m);
  print_square_matrix(m);

  printf("risultato= %d\n", f(m,v));

  return 0;
}

void read_vector(int v[]){
  int i;
  for(i=0;i<N;i++){
    scanf("%d",&v[i]);
  }
  printf("\n");
}

void read_square_matrix(int m[][N]){
  int r,c;
  printf("Inserire matrice\n");
  for (r=0; r<N; r++)
    for (c=0; c<N;c++)
      scanf("%d", &m[r][c]);
  printf("\n");
}

void print_square_matrix(int m[][N]){
  printf("Inserted matrix:\n");
  int r,c;
  for (r=0;r<N;r++){
    for (c=0;c<N;c++)
      printf(" %d ", m[r][c]);
    printf("\n");
  }
}

int f(int m[][N], int v[]){
  int i,j,flag=1,flag_r=1;

  /* check riga*/
  for(i=0;i<N;i++){
    flag=1;
    flag_r=1;
    for(j=0;j<N;j++){
      if(m[i][j]!=v[j])
        flag=0;
      if(m[i][N-1-j]!=v[j])
        flag_r=0;
    }
    if(flag==1 || flag_r==1)
      return 1;
  }

  /* check colonna*/
  for(i=0;i<N;i++){
    flag=1;
    flag_r=1;
    for(j=0;j<N;j++){
      if(m[j][i]!=v[j])
        flag=0;
      if(m[N-1-j][i]!=v[j])
        flag_r=0;
    }
    if(flag==1 || flag_r==1)
      return 1;
  }

  /* diagonale 1*/
  flag=1;
  flag_r=1;
  for(j=0;j<N;j++){
    if(m[j][j]!=v[j])
      flag=0;
    if(m[N-1-j][N-1-j]!=v[j])
      flag_r=0;
  }
  if(flag==1 || flag_r==1)
    return 1;

  /* diagonale 2*/
  for(j=0; j < N;j++) {
    if(m[N-1-j][j]!=v[j])
      flag=0;
    if(m[j][N-1-j]!=v[j])
      flag_r=0;
  }
  if(flag==1 || flag_r==1)
    return 1;

  return 0;
}
