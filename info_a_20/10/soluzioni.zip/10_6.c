/*
Scrivere una funzione void f(int M[][N], int V[], int K) che riceve una matrice M di interi di dimensioni N × N , un vettore V di interi di lunghezza
N (con N costante globale definita con una #define) e un intero K e copia nel vettore V la riga di M che ha la media dei valori contenuti più vicina a K (si supponga che sia sempre una sola).
*/
#include <stdio.h>
#define N 4

void f(int [][N],int [],int);
void copy(int [], int []);
float mean(int []);
float distance(int k, float mean);

void main(){
  // 1, 1.75, 3,5, 0
  int m[N][N]={{0,1,3,0},{2,3,2,0},{3,7,1,3},{0,0,0,0}};
  int i,k=2 ,v[N];

  f(m,v,k);

  printf("v: ");
  for(i=0;i<N;i++){
    printf("%d ",v[i]);
  }
}

void f(int m[][N],int v[],int k){
  int i;
  float d,avg;

  //first row to initialize d
  avg=mean(m[0]);
  d=distance(k,avg);
  copy(m[0], v);

  for(i=1;i<N;i++){
    avg=mean(m[i]);
    if(distance(k,avg)<d){
      d=distance(k,avg);
      copy(m[i], v);
    }
  }
}

// copy a into b
void copy(int a[],int b[]){
  int i;
  for(i=0;i<N;i++){
    b[i]=a[i];
  }
}

float mean(int v[]){
  float mean=0;
  int i;
  for(i=0;i<N;i++){
    mean += v[i];
  }
  return mean/N;
}

float distance(int k,float mean){
  float d;
  if (mean >= k)
    d=mean-k;
  else
    d=k-mean;
  return d;
}
