/* Scrivere una funzione void f(int M[][N]), con N costante predefinita, che
faccia scorrere di una posizione le righe della matrice verso il basso. L’ultima riga diventa la riga in testa alla matrice.
Utilizzare una funzione ausiliaria void copy(int a[],int b[]) che copia il vettore a
nel vettore b.*/
#include <stdio.h>
#define N 4

void f(int [][N]);
void copy(int [], int []);

void main(){
  int M[N][N]={{0,0,0,0},{1,1,1,1},{2,2,2,2},{1,2,3,4}};
  int i,j,v[N];

  f(M);

  //print
  for(i=0;i<N;i++){
    for(j=0;j<N;j++){
      printf("%d ",M[i][j]);
    }
    printf("\n");
  }
}

void f(int M[][N]){
  int aux[N];
  int i;
  // salviamo l'ultima riga in aux
  copy(M[N-1],aux);
  //partendo dal basso spostiamo le righe
  for(i=N-2;i>=0;i--){
    //la righa i è quella che vogliamo spostare in basso
    copy(M[i],M[i+1]);
  }
  // copiamo aux nella prima riga
  copy(aux,M[0]);
}

void copy(int *v1, int *v2){
  int i;
  for(i=0;i<N;i++){
    v2[i]=v1[i];
  }
}
