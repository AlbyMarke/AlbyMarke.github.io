#include<stdio.h>
#include<stdlib.h>

#define N 100

typedef struct NodeM{
	int m[N][N];
	struct NodeM *next;
}NodoM;
typedef NodoM * ListaM;

typedef struct NodeL{
	int n;
	struct NodeL *next;
}NodoL;
typedef NodoL * ListaL;

ListaL f(ListaM, int);
int cerca(int [][N],int);

int main(){
	//SOMETHING
	return 0;
}

int cerca(int m[N][N], int k){
	int cur=k,i,j;

	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			if(m[i][j]>k){
				if(cur==k){
					cur=m[i][j];
				}else{
					if(m[i][j]<cur)
						cur=m[i][j];
				}
			}
		}
	}
	return cur;
}

ListaL f(ListaM lm, int k){
	ListaL h= NULL,tmp;
	ListaM cur=lm;
	int i;

	while(cur!=NULL){
		i=cerca(cur->m,k);
		if(i>k){
			tmp=(ListaL)malloc(sizeof(NodoL));
			if(tmp==NULL)
				return NULL;
			tmp->n=i;
			tmp->next=h;
			h=tmp;
		}
		cur=cur->next;
	}
	return h;
}