#include<stdio.h>
#include<stdlib.h>

typedef struct el{
	int v;
	struct el *left;
	struct el * right;
}Nodo;
typedef Nodo * Tree;

int isobato(Tree);
Tree insert(Tree, int);
int check_isobato(Tree);
int max_depth(Tree t);
int min_depth(Tree t);
int isobato2(Tree t);

int main(){
	Tree t=NULL;

	t=insert(t,12);
	t=insert(t,1);
	t=insert(t,20);

	printf("%d\n",isobato2(t));

	t=insert(t,15);

	printf("%d\n",isobato2(t));

	return 0;
}

Tree insert(Tree t, int x){
	Tree tmp;

	if(t==NULL){
		tmp=(Tree)malloc(sizeof(Nodo));
		tmp->v=x;
		tmp->left=NULL;
		tmp->right=NULL;
		return tmp;
	}

	if(x < t->v){
		t->left=insert(t->left,x);
	}else if(x > t->v){
		t->right=insert(t->right,x);
	}

	return t;
}

int check_isobato(Tree t){
	int l,r;

	if(t==NULL)
		return 0;

	l=check_isobato(t->left);
	r=check_isobato(t->right);

	printf("nodo %d l %d r %d\n", t->v,l,r);

	if(l==-1 || r==-1)
		return -1;
	if(l==r)
		return r+1;
	if(r==0)
		return l+1;
	if(l==0)
		return r+1;
	return -1;
}

int isobato(Tree t){
	if(check_isobato(t)==-1)
		return 0;
	return 1;
}

int max_depth(Tree t){
	int d,s;
	if(t==NULL)
		return 0;
	s=max_depth(t->left);
	d=max_depth(t->right);
	if(s>d)
		return s+1;
	else
		return d+1;
}

int min_depth(Tree t){
	int d,s;
	if(t==NULL)
		return 0;
	s=min_depth(t->left);
	d=min_depth(t->right);
	if(s==0)
		return d+1;
	if(d==0)
		return s+1;
	if(s<d)
		return s+1;
	else
		return d+1;
}

int isobato2(Tree t){
	return max_depth(t) == min_depth(t);
}