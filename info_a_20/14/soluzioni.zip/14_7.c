#include<stdio.h>
#include<stdlib.h>

typedef struct el{
	int v;
	struct el *left;
	struct el * right;
}Nodo;
typedef Nodo * Tree;

int eq(Tree,Tree);
Tree insert(Tree, int);

int main(){
	Tree t=NULL,t1=NULL,t2=NULL;

	t=insert(t,12);
	t=insert(t,1);
	t=insert(t,12);
	t=insert(t,20);
	t=insert(t,21);
	t=insert(t,15);

	t1=insert(t1,12);
	t1=insert(t1,1);
	t1=insert(t1,12);
	t1=insert(t1,20);
	t1=insert(t1,21);
	t1=insert(t1,15);

	t2=insert(t2,12);
	t2=insert(t2,1);
	t2=insert(t2,12);
	t2=insert(t2,20);
	t2=insert(t2,22);
	t2=insert(t2,15);

	printf("t equal t1: %d\n t  equal t2: %d\n", eq(t,t1), eq(t,t2));

	return 0;
}

Tree insert(Tree t, int x){
	Tree tmp;

	if(t==NULL){
		tmp=(Tree)malloc(sizeof(Nodo));
		tmp->v=x;
		tmp->left=NULL;
		tmp->right=NULL;
		return tmp;
	}

	if(x < t->v){
		t->left=insert(t->left,x);
	}else if(x > t->v){
		t->right=insert(t->right,x);
	}

	return t;
}

int eq(Tree t1, Tree t2){
	if(t1==NULL && t2==NULL)
		return 1;
	if(t1==NULL || t2==NULL)
		return 0;
	return (t1->v==t2->v && 
		eq(t1->left,t2->left) && eq(t1->right,t2->right));
}