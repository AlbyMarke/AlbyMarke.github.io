#include<stdio.h>
#include<stdlib.h>

typedef struct nodo{
	int v;
	struct nodo *next;
}Nodo;
typedef Nodo * Lista;

Lista ins_coda(Lista, int);
void print_lista(Lista);
Lista ds(Lista, Lista, Lista);
Lista ds_testa(Lista ,Lista);
Lista ins_testa(Lista,int);

int main(){
	Lista l1=NULL, l2=NULL, res=NULL;

	l1=ins_coda(l1,1);
	l1=ins_coda(l1,2);
	l1=ins_coda(l1,10);
	l1=ins_coda(l1,20);
	print_lista(l1);

	l2=ins_coda(l2,2);
	l2=ins_coda(l2,3);
	l2=ins_coda(l2,4);
	l2=ins_coda(l2,10);
	print_lista(l2);

	//res=ds(l1,l2,res);
	res=ds_testa(l1,l2);
	print_lista(res);

	return 0;
}

Lista ins_coda(Lista l, int n){
	if(l==NULL){
		l=(Lista)malloc(sizeof(Lista));
		l->next=NULL;
		l->v=n;
	}else{
		l->next=ins_coda(l->next,n);
	}
	return l;
}

Lista ins_testa(Lista l, int n){
	Lista newptr;
	newptr=(Lista)malloc(sizeof(Lista));
	if(newptr!=NULL){
		newptr->v=n;
		newptr->next=l;
		l=newptr;
	}
	return l;
}

void print_lista(Lista l) {
    if (l == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d ---> ", l->v);
    	print_lista(l->next);
    }
}

Lista ds(Lista l1,Lista l2,Lista res){
	if(l1==NULL && l2==NULL)
		return res;
	if(l1==NULL || (l2!=NULL && l1->v > l2->v)){
		res = ins_coda(res,l2->v);
		return ds(l1,l2->next,res);
	}
	if(l2==NULL || (l1!=NULL && l2->v > l1->v)){
		res = ins_coda(res, l1->v);
		return ds(l1->next,l2,res);
	}
	return ds(l1->next,l2->next,res);
}

// variante con inserimento in testa
Lista ds_testa(Lista l1, Lista l2){
	Lista tmp;
	// entrambi finiti
	if(l1==NULL && l2==NULL)
		return NULL;
	// elementi uguali, scorro entrambe le liste
	if(l1!=NULL && l2!= NULL && l1->v==l2->v)
		return ds_testa(l1->next, l2->next);

	//se sono qui devo allocare un nuovo elemento
	tmp=(Lista)malloc(sizeof(Nodo));

	if(l2==NULL || (l1!=NULL && l1->v < l2->v)){
		tmp->v=l1->v;
		l1=l1->next;
	}else{
		tmp->v=l2->v;
		l2=l2->next;
	}
	tmp->next=ds_testa(l1,l2);
	return tmp;
}
