#include<stdio.h>
#include<stdlib.h>

#define N 5

typedef struct nodo{
	int v;
	struct nodo *next;
}Nodo;
typedef Nodo * Lista;

Lista ins_testa(Lista, int);
void print_lista(Lista);
int n_elements(Lista);
int mediana(Lista);

int main(){
	Lista l=NULL;
	int i;

	l=ins_testa(l,1);
	l=ins_testa(l,6);
	l=ins_testa(l,2);
	l=ins_testa(l,3);
	l=ins_testa(l,5);
	print_lista(l);

	printf("Mediana: %d\n",mediana(l));

	return 0;
}

Lista ins_testa (Lista l, int val) {
	Lista newPtr;
	newPtr = (Lista) malloc(sizeof(Nodo));
	if(newPtr!=NULL){
		newPtr->v=val;
		newPtr->next=l;
	}else{
		printf("No memory available\n");
	}
	return newPtr;
}

void print_lista(Lista l) {
    if (l == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d ---> ", l->v);
    	print_lista(l->next);
    }
}

int n_elements(Lista l){
	int n=0;
	if(l!=NULL){
		while(l!=NULL){
			n++;
			l=l->next;
		}
	}
	return n;
}

int mediana(Lista l){
	Lista c1, c2;
	int len_lista=0,lower,higher;

	len_lista=n_elements(l);

	// escludiamo il caso in cui la lista abbia un numero di elementi pari
	// perché non sono ammessi duplicati
	if(len_lista==0 || len_lista%2==0){
		printf("Lista non valida\n");
		return -1;
	}
	else{
		c1=l;
		while(c1!=NULL){
			c2=l;
			lower=0;
			higher=0;
			while(c2!=NULL){
				if(c2->v>c1->v)
					higher++;
				else
					// è necessario!
					if(c2->v<c1->v)
						lower++;
				c2=c2->next;
			}
			printf("%d higher: %d, lower:%d\n",c1->v,higher,lower);
			if(higher==lower)
				return c1->v;
			c1=c1->next;
		}
	}
	return -1;
}



