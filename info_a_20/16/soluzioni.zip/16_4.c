#include<stdio.h>
#include<stdlib.h>

typedef struct Nodo_s{
	int v;
	struct Nodo_s *left, *right;
}Node;
typedef Node *Tree;

int sf(Tree);
int cerca(Tree,int);
int f(Tree,Tree);

int main(){
	//something...
	return 0;
}

// calcola la somma dei nodi foglia
int sf(Tree t){
	if(t==NULL)
		return 0;
	if(t->left==NULL && t->right==NULL)
		return t->v;
	return sf(t->left) + sf(t->right);
}

// cerca in un albero (non ordinato) un elemento con un valore dato
int cerca(Tree t, int x){
	if(t==NULL)
		return 0;
	if(t->v==x)
		return 1;
	return cerca(t->left, x) || cerca(t->right, v);
}

int f(Tree t1, Tree t2){
	return cerca(t1, somma(t2)) || cerca(t2, somma(t1));
}
