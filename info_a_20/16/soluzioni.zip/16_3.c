#include<stdio.h>
#include<stdlib.h>

/* Una soluzione alternativa è calcolando la min_depth e la
 max_depth come mostrato in Esercizio 14.8.
 Provare come esercizio a fare la stessa cosa con albero ternario. */

typedef struct Elemento{
	int v;
	struct Elemento *left,*center,*right;
}Nodo;
typedef Nodo * Tree;

int isobato(Tree);
int check_isobato (Tree t);

int main(){
	//something..
	return 0;
}

int isobato(Tree t){
	if (check_isobato(t) == -1)
        return 0;
    return 1;
}

/* Ritorna -1 se la proprietà non è verificata,
 altrimenti ritorna la lunghezza dei cammini. */
int check_isobato (Tree t) {
    int l, c, r;
    if (t == NULL)
        return 0;
    l = check_isobato(t->left);
    c = check_isobato(t->center);
    r = check_isobato(t->right);
    if (l == -1 || c == -1 || r == -1)
        return -1;
    if (l == c && c == r)
        return l+1;
    if (l == 0 && c == r)
        return c+1;
    if (c == 0 && l == r)
        return l+1;
    if (r == 0 && l == c)
        return l+1;
    return -1;
}
