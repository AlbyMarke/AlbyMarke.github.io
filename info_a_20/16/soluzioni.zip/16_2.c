#include<stdio.h>
#include<stdlib.h>

typedef struct Node_s{
	int v;
	struct Node_s * next;
}Node;
typedef Node *Lista;

Lista ins_testa(Lista,int);
int ond(Lista l);

int main(){

	Lista l=NULL;

	l=ins_testa(l,2);
	l=ins_testa(l,1);
	l=ins_testa(l,2);
	l=ins_testa(l,3);
	l=ins_testa(l,4);

	printf("check 1, res: %d\n", ond(l));

	l=NULL;
	l=ins_testa(l,2);
	l=ins_testa(l,4);
	l=ins_testa(l,1);
	l=ins_testa(l,3);

	printf("check 2, res: %d\n", ond(l));

	return 0;
}

Lista ins_testa (Lista l, int val) {
	Lista newPtr;
	newPtr = (Lista) malloc(sizeof(Node));
	if(newPtr!=NULL){
		newPtr->v=val;
		newPtr->next=l;
	}else{
		printf("No memory available\n");
	}
	return newPtr;
}

int ond(Lista l){
	Lista iter,p1,p2; //p1 e p2 punteranno agli elementi precedenti
	int c=0;

	while(iter!=NULL){
		c++;
		if(c==1){
			p1=iter;
		}else if (c==2){
			p2=iter;
		}
		else{
			if((p1->v > p2->v && p2->v > iter->v) ||
				(p1->v < p2->v && p2->v < iter-> v)){
				return 0;
			}else{
				p1=p2;
				p2=iter;
			}
		}
		iter=iter->next;
	}
	return 1;
}
