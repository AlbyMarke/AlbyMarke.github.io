#include <stdio.h>
#include <stdlib.h>

#define N 10

typedef struct qNode {
  int data;
  struct qNode *nextPtr;
} QueueNode;

typedef QueueNode *QueueNodePtr;

void printQueue( QueueNodePtr );
int isEmpty( QueueNodePtr );
int dequeue( QueueNodePtr *, QueueNodePtr * );
void enqueue( QueueNodePtr *, QueueNodePtr *, int );

int main(){
  QueueNodePtr firstPtr = NULL, lastPtr= NULL;
  int i;

  for(i=0; i<N; i++)
  	enqueue(&firstPtr, &lastPtr, i);

  printQueue(firstPtr);

  dequeue(&firstPtr, &lastPtr);

  printQueue(firstPtr);

  return 0;
}


int isEmpty(QueueNodePtr curPtr){
  return curPtr == NULL;
}

void printQueue(QueueNodePtr curPtr){
  if(curPtr==NULL)
  	printf("Queue is empty\n");
  else{
  	printf("The queue is:\n");
  	while(curPtr!= NULL){
  		printf("%d-->",curPtr->data);
  		curPtr=curPtr->nextPtr;
  	}
  	printf("NULL\n\n");
  }
}

int dequeue(QueueNodePtr *firstPtr, QueueNodePtr *lastPtr){
	QueueNodePtr tempPtr = *firstPtr;
	int val = (*firstPtr)->data;
	*firstPtr = (*firstPtr)->nextPtr;
	if(*firstPtr==NULL)
		*lastPtr=NULL;
	free(tempPtr);
	return val;
}

void enqueue(QueueNodePtr *firstPtr, QueueNodePtr *lastPtr, int val){
	QueueNodePtr newPtr;
	newPtr=malloc(sizeof(QueueNode));
	if(newPtr!=NULL){
		newPtr->data=val;
		newPtr->nextPtr=NULL;
		if(isEmpty(*firstPtr))
			*firstPtr=newPtr;
		else
			(*lastPtr)->nextPtr=newPtr;
		*lastPtr=newPtr;
		printf("Allocato: %d\n",val);
	}
	else
		printf("No memory available\n");
}