#include <stdio.h>
#include <string.h>

#define MAX_C 30
#define MAX_S 10

/* Dichiarazione tipi */

typedef struct { 
	char nomestud[100];
	char cognstud[100];
	int eta; 
} Studente;

typedef struct { 
	char lingua[10] ;
    int liv;
    int numiscritti;
    char nomeinsegn[15];
    Studente alunni[MAX_S];
} Corso;

int main () {

	/* inserimento dati di 4 classi */
	Corso ScuolaLingue[MAX_C]=
		{{"inglese",1,2,"maestr1","alice","ferrari",8,"luca","bianchi",8},
		{"inglese",2,2,"maestr2","guzzi","tommi",18,"gialli","fede",18},
		{"inglese",1,2,"maestr3","innoi","ldddd",10,"sssss","ddddd",10},
		{"spagnolo",2,2,"maestr4","ducai","ddddd",5,"wwwww","qqqqq",5}};
		
	int i,j,cont = 0;
	float somma = 0;
				
	for (i = 0 ; i < MAX_C; i++) { 
		if(strcmp("inglese", ScuolaLingue[i].lingua) == 0){
			for(j = 0; j < ScuolaLingue[i].numiscritti; j++) {
				cont++;
				somma += ScuolaLingue[i].alunni[j].eta;
			}
		}
	}
	
	if (cont > 0) 
		printf("\nL'eta' media e':%f \n", somma/cont);
	else 
		printf("\nNessun corso di inglese \n");

}




