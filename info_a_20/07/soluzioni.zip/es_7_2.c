#include <stdio.h> 
#define LEN 5

int main() {
	char a[LEN];
	int i;
	char *p, *q;
	for (i = 0; i < LEN; i++) {
		a[i] = 'A'; 
	}
	p = a;
	*p += 15;
	q = p + 3;
	*q += 8;
	*(q - 1) = 76;
	p = p + 1;
	*p = (*(p - 1) - 1); 
	a[LEN -1] = '\0';
	printf("%s\n", a);
}




