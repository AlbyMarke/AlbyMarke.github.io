#include <stdio.h>
#define N 3

int main () {

	int m[N][N], v[N];
	int k, r, c, i;
	int cont, flag;
	
	printf("Inserire matrice:\n");
	for (r = 0; r < N; r++)
		for (c = 0; c < N; c++) 
			scanf("%d", *(m + r) + c);
			
	printf("Inserire vettore:\n");
	for (i = 0; i < N; i++) 
		scanf("%d", v + i);
	
	do {
	
		printf("Inserire valore di K:");
		scanf("%d", &k);
	
	} while (k <= 0 || k > N);
	
	flag = -1;
	for (r = 0; r < N && flag == -1; r++) {
	
		cont = 0;
		
		for (c = 0; c < N; c++) {
		
			for (i = 0; i < N; i++)
				if (*(*(m + r) + c) == *(v + i)) cont ++;
		
		}
		
		if (cont == k) flag = r;
	}
	
	printf("%d\n", flag);

}