#include <stdio.h>
#define N 10

typedef struct {
	int x;
	int y;
} Punto;

typedef struct {
	Punto v[N];
	int n;
} ElencoPunti;

int main() {

	ElencoPunti ele = {{{7, 2}, {1, 3}, {0, 5}, {6, 0}}, 4};
	int i;
	Punto *mx, *my;
	
	mx = &ele.v[0];
	my = &ele.v[0];
	for (i = 1; i < ele.n; i++) {
	
		if (ele.v[i].x > mx->x) {
			mx = &ele.v[i];
		}
		if (ele.v[i].y > my->y) {
			my = &ele.v[i];
		}
	
	}
	
	if (mx == my)
		printf("x: %d; y: %d \n", mx->x, mx->y);
	else 
		printf("x: %d; y: %d \n", mx->x + my->x, mx->y + my->y);

}
