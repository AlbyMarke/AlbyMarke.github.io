#include <stdio.h>
#include <string.h>

/* definizioni dei tipi */
typedef struct {		
	char nome[20], cognome[20]; 
	int stipendio;
	int cat; // contiene valori tra 1 e 5 int stipendio;
} Impiegato;

typedef struct { 
	int superficie; /*in m^2*/ 
	char esp[20];
    Impiegato occupante;
} Ufficio;

int main () {	

	/* definizioni delle variabili */
	Ufficio torre[20][40]; /* rappresenta un edificio di 20 piani con 40 uffici per piano */
	Ufficio uff1 = {15, "sudEst", {"Giacomo", "Boracchi", 2000, 5}};
	torre[0][0] = uff1;
	Ufficio uff2 = {10, "nord", {"Andrea", "Celli", 1500, 3}};
	torre[1][0] = uff2;
	
	int p, u; /* indice di piano nell’edificio e di ufficio nel piano */
	int uffNord; /* uffNord fa da flag*/ 
	Ufficio vett1[20*40];
	Impiegato vett2[20*40];
	int i;
	
	/* Punto 1 */
	for (p=0; p<20; p++)
		for (u=0; u<40; u++)
			if ((strcmp(torre[p][u].esp, "sudEst") == 0) || ((strcmp(torre[p][u].esp, "sud") == 0)
				&& (torre[p][u].superficie >= 20
				&& torre[p][u].superficie <= 30))) {
					printf("\n il Signor %s è impiegato di categoria %d", torre[p][u].occupante.cognome, torre[p][u].occupante.cat);
					printf (" e ha uno stipendio pari a %d euro \n", torre[p][u].occupante.stipendio);
				}
		
	/* Punto 2: Stampa piani senza uffici esposti a nord */			
	for (p=0; p<20; p++) {
  		uffNord = 0;//flag = 0 in ogni piano
  		for (u=0; u<40 && uffNord == 0; u++)
     		if(strcmp(torre[p][u].esp, "nord") == 0)
       			uffNord = 1;
		/* se qui vale ancora 0 vuol dire che non ci sono uffici a nord*/
  		if (uffNord == 0)
     		printf("il piano %d  non ha edifici esposti a nord \n", p); 
     }
     
     /* Punto 3: Cerca l'ufficio del Prof. Boracchi */
     for (p=0; p<20; p++)
		for (u=0; u<40; u++)
			if ((strcmp(torre[p][u].occupante.cognome, "Boracchi") == 0) && 
				(strcmp(torre[p][u].occupante.nome, "Giacomo") == 0)) {
					printf("\nL'ufficio del Prof. Boracchi è il numero %d al piano %d \n", u, p);
				}
	
	/* Punto 4: Copia uffici di dipendenti di categoria 5 in vettore */			
	for (p=0; p<20; p++)
		for (u=0; u<40; u++)
			if (torre[p][u].occupante.cat == 5) {
				vett1[i] = torre[p][u];
				i++;
			}
			
	/* Punto 5: Copia dipendenti di categoria 5 in vettore */			
	int j;
	for (j = 0; j < i; j++) {
		vett2[j] = vett1[j].occupante;
	}

}
