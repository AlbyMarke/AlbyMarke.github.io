#include<stdio.h>
#include<stdlib.h>

typedef struct Nodo_s{
	int v;
	struct Nodo_s *next;
}Nodo;
typedef Nodo *Lista;

typedef struct NodoCompresso{
	int v,n;
	struct NodoCompresso *next;
}NodoC;
typedef NodoC *ListaC;

Lista ins_testa(Lista,int);
void print_lista(Lista);
void print_listaC(ListaC);
ListaC comprimi(Lista);

int main(){

	Lista l=NULL;
	ListaC lc=NULL;

	l=ins_testa(l,5);
	l=ins_testa(l,5);
	l=ins_testa(l,3);
	l=ins_testa(l,2);
	l=ins_testa(l,2);
	l=ins_testa(l,3);
	l=ins_testa(l,3);
	l=ins_testa(l,3);
	l=ins_testa(l,3);

	lc=comprimi(l);

	print_lista(l);
	print_listaC(lc);


	return 0;
}

Lista ins_testa (Lista l, int val) {
	Lista newPtr;
	newPtr = (Lista) malloc(sizeof(Nodo));
	if(newPtr!=NULL){
		newPtr->v=val;
		newPtr->next=l;
	}else{
		printf("No memory available\n");
	}
	return newPtr;
}

void print_lista(Lista l) {
    if (l == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d ---> ", l->v);
    	print_lista(l->next);
    }
}

void print_listaC(ListaC l){
	if(l==NULL)
		printf("---|\n");
	else{
		printf("(%d,%d)---> ", l->v, l->n);
		print_listaC(l->next);
	}
}

ListaC comprimi (Lista l){
	ListaC lc = NULL, tmpc = NULL, newel = NULL;
	Lista tmp; 
	int c;

	if (l == NULL)
		return NULL;

	while (l != NULL){

		tmp = l->next;
		c = 1;

		while (tmp != NULL && tmp->v == l->v){
			c++;
			tmp = tmp->next;
		}

		newel = (ListaC)malloc(sizeof(NodoC));
		if (newel != NULL){
			newel->v = l->v;
			newel->n = c;
			newel->next = NULL;

			if(lc == NULL){
                // Lista compressa vuota
				lc = newel;
				tmpc = newel;
			}else{
				// Almeno un elemento già presente
				tmpc->next=newel;
				tmpc=newel;
			}
		}

		l = tmp;
	}
	return lc;
}

ListaC comprimi2 (Lista l){
    ListaC lc = NULL, curc = NULL, precc = NULL, newel = NULL;
    Lista tmp;
    int c;
    int trovato;

    if(l == NULL)
        return NULL;

    while (l != NULL){

        // Controllo se ho già inserito l'elemento
        trovato = 0;
        curc = lc;
        while (curc != NULL && !trovato)
            if (curc->v == l->v)
                trovato = 1;
        
        if (!trovato) {
            
            tmp = l->next;
            c = 1;
            
            while (tmp != NULL && tmp->v == l->v){
                c++;
                tmp = tmp->next;
            }

            newel = (ListaC)malloc(sizeof(NodoC));
            if (newel != NULL){
                newel->v = l->v;
                newel->n = c;
                
                if (lc == NULL) {
                    newel->next = NULL;
                    lc = newel;
                } else {
                    // Inserimento ordinato
                    curc = lc;
                    precc = NULL;
                    while (curc != NULL && newel->v > curc->v) {
                        precc = curc;
                        curc = curc->next;
                    }
                    newel->next = curc;
                    if (precc != NULL)
                        // Inserimento in mezzo
                        precc->next = newel;
                    else
                        // Inserimento in testa
                        lc = newel;
                }
            }
        }

        l = tmp;
    }
    return lc;
}
