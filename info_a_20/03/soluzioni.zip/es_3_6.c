#define DIM 30

#include <stdio.h>

int main()
{
    // indici per scansione
    int i, j;

    // dimensione effettiva degli array
    int dim_a, dim_b;

    // flag utile per le ricerche di elementi
    int trovato;

    // array e insiemi A e B
    int lista[DIM];
    int A[DIM];
    int B[DIM];

    // dimensione effettiva degli insiemi
    int len_a = 0;
    int len_b = 0;
    int len_u = 0; //dimensione unione
    int len_i = 0; //dimensione intersezione
    int len_d = 0; //dimensione differenza

    // altri insiemi
    int unione[2*DIM];    // A u B
    int intersezione[DIM]; // A ^ B
    int differenza[DIM];  // B \ A

    /*
     * ACQUISIZIONE DELLA DIMENSIONE DELLA PRIMA LISTA
     */
    do {
        printf("Quanti elementi vuoi inserire nella prima lista (max: %d)? ",
               DIM);
        scanf("%d", &dim_a);

        if (dim_a > DIM)
            printf("Valore inserito troppo grande!\n");
    } while (dim_a > DIM);

    /*
     * ACQUISIZIONE DELLA PRIMA LISTA DI ELEMENTI
     */
    for (i = 0; i < dim_a; i++) {
        printf("Inserire il %do elemento: ", i+1);
        scanf("%d", &lista[i]);
    }

    /*
     * CONVERSIONE IN INSIEME A
     */
    for (i = 0; i < dim_a; i++) {
        trovato = 0;

        //ricerco il valore i-esimo nella lista
        for (j = 0; !trovato && j < len_a; j++)
            trovato = (lista[i] == A[j]);

        //se non trovato, lo inserisco e incremento l'indice
        if (!trovato) {

            A[len_a] = lista[i];
            len_a++;
        }
    }

    /*
     * ACQUISIZIONE DELLA DIMENSIONE DELLA SECONDA LISTA
     */
    do {
        printf("Quanti elementi vuoi inserire nella seconda lista (max: %d)? ",
               DIM);
        scanf("%d", &dim_b);

        if (dim_b > DIM)
            printf("Valore inserito troppo grande!\n");
    } while (dim_b > DIM);

    /*
     * ACQUISIZIONE DELLA SECONDA LISTA DI ELEMENTI
     */
    for (i = 0; i < dim_b; i++) {
        printf("Inserire il %do elemento: ", i+1);
        scanf("%d", &lista[i]);
    }

    /*
     * CONVERSIONE IN INSIEME B
     */
    for (i = 0; i < dim_b; i++) {
        trovato = 0;

        //ricerco il valore i-esimo nella lista
        for (j = 0; !trovato && j < len_b; j++)
            trovato = (lista[i] == B[j]);

        //se non trovato, lo inserisco e incremento l'indice
        if (!trovato) {
            B[len_b] = lista[i];
            len_b++;
        }
    }
    
    /*
	 * UNIONE: Tutti gli elementi in A e tutti gli elementi in B
     * senza ripetizioni.
     *
     * INTERSEZIONE: Tutti gli elementi che sono sia in A che in
     * B, senza ripetizioni.
     *
     * DIFFERENZA: Tutti gli elementi che sono in B, tranne
     * quelli che sono in A.
     */
     
    // copio insieme A in insieme unione
    for (i = 0; i < len_a; i++) {
    	unione[len_u] = A[i];
    	len_u++;
    }
     
    for (i = 0; i < len_b; i++) {
    
    	// comincio controllando se valore i-esimo di B va nell'insieme unione
    	trovato = 0;
    	
    	// ricerco il valore i-esimo di B nell'insieme unione
        for (j = 0; !trovato && j < len_u; j++)
            trovato = (B[i] == unione[j]);

        // se non trovato, allora va aggiunto all'unione
        if (!trovato) {
            unione[len_u] = B[i];
            len_u++;
        }
    
    	// controllo se valore i-esimo di B va nell'insieme intersezione o differenza
    	trovato = 0;
    	
    	// ricerco il valore i-esimo di B nell'insieme A
        for (j = 0; !trovato && j < len_a; j++)
            trovato = (B[i] == A[j]);

        // trovato anche in A: allora fa parte dell'intersezione
        if (trovato) {
        
        	// non mi serve controllare che l'elemento non sia gi� in intersezione, perch� B � un insieme  
            intersezione[len_i] = B[i];
            len_i++;
                
        } else { //non trovato in A: allora fa parte della differenza
        
        	// non mi serve controllare che l'elemento non sia gi� in differenza, perch� B � un insieme
            differenza[len_d] = B[i];
            len_d++;
        }
    }
    
    // stampa l'insieme A
    printf ("Insieme A = { ");
    for (i = 0; i < len_a; i++)
        printf("%d ", A[i]);
    printf ("}\n");

    // stampa l'insieme B
    printf ("B = { ");
    for (i = 0; i < len_b; i++)
        printf("%d ", B[i]);
    printf ("}\n");

    // stampa l'insieme unione
    printf ("unione = { ");
    for (i = 0; i < len_u; i++)
        printf("%d ", unione[i]);
    printf ("}\n");

    // stampa l'insieme intersezione
    printf ("intersezione = { ");
    for (i = 0; i < len_i; i++)
        printf("%d ", intersezione[i]);
    printf ("}\n");

    // stampa l'insieme differenza
    printf ("differenza = { ");
    for (i = 0; i < len_d; i++)
        printf("%d ", differenza[i]);
    printf ("}\n");
}

