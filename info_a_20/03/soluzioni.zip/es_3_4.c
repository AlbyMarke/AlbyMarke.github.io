#include <stdio.h>

#define MAX_LEN 8

int main() {

	int num;
	int vett[MAX_LEN];
	int i;
	int estremo = 1, positivo;
	int flag;
	
	// calcolo estremi valori che posso rappresentare
	for (i = 0; i < MAX_LEN; i++) {
	
		// inizializzo a zero per essere sicuro che tutto sia corretto anche se uso meno bit
		vett[i] = 0;
		
		estremo = estremo * 2;
	}
	estremo = estremo / 2;

	do {
		flag = 0;
		
    	printf("Inserire il numero che si vuole convertire in CP2 (min: %d; max: %d): ", 
    		-estremo, estremo-1);
    	scanf("%d", &num);
    	
    	// numero inserito fuori dagli estremi
    	if (num < -estremo || num >= estremo) {
    		printf("Valore inserito fuori dall'intervallo!");
    		flag = 1;
    	}
    	
	} while (flag);
	
	positivo = num >= 0;
	
	// se numero negativo allora cambio segno (devo prima convertire il suo opposto)
	if (!positivo)
		num = -num;
	
	// metodo divisioni successive per 2
	for (i = 0; i < MAX_LEN; i++) {
		vett[i] = num % 2;
		num = num / 2;
	} 
	
	// se numero era negativo
	if (!positivo) {
	
		// complemento
		for (i = 0; i < MAX_LEN; i++) {
			if (vett[i] == 0)
				vett[i] = 1;
			else
				vett[i] = 0;
		}
		
		// sommo 1
		flag = 0;
		for (i = 0; !flag && i < MAX_LEN; i++) {
			if (vett[i] == 0) {
				vett[i] = 1;
				flag = 1;
			}
			else
				vett[i] = 0;
		}
	}
	
	/* Stampa il numero in CP2 */ 
	for (i = MAX_LEN - 1; i >= 0; i--) 
		printf("%d ", vett[i]); 
	printf("\n");
		
}
