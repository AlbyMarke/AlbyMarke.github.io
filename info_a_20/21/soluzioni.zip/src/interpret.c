#include<stdio.h>
#include<stdlib.h>
#define M 6

void m(int k);
void f(int * a, int b, int c);
void g(int* d, int e);

int main(){
    m(1);
    m(2);
    m(4);
    m(12);
    m(24);
}
void m(int k) {
    int* h = (int*) malloc(sizeof(int) * M);
    
    f(h + M - 1, k, 0);
    
    g(h, M);
    
    if(h)
        free(h);
}

void f(int * a, int b, int c) {
    if(c == M)
        return;
    c++;
    *(a) = b % 2;
    a--;
    
    f(a, b/2, c);
}

void g(int* d, int e) {
    if (e) {
        printf("%d", *d);
        d++;
        g(d, e-1);
    } else printf("\n");
}
