#include <stdio.h>
#include <stdlib.h>

typedef int TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista InsInTesta (Lista lista, TipoElem elem);
void VisualizzaLista(Lista lista);
int VerificaPresenza(Lista lista, TipoElem elem);
int VerificaPresenza_ric(Lista lista, TipoElem elem);

int main () {

	Lista lis = NULL;
	int x = 1;
	
	lis = InsInTesta(lis, 2);
	lis = InsInTesta(lis, 5);
	lis = InsInTesta(lis, 3);
	lis = InsInTesta(lis, 1);
	lis = InsInTesta(lis, 7);
	lis = InsInTesta(lis, 6);
	
	VisualizzaLista(lis);
	printf("\n");	
	
	printf("Verifica presenza di %d in lista: %d \n", x, VerificaPresenza(lis,x));
	printf("Verifica presenza (ric) di %d in lista: %d \n", x, VerificaPresenza_ric(lis,x));	
	
}	

Lista InsInTesta (Lista lista, TipoElem elem) {
	Lista punt;
	punt = (Lista) malloc(sizeof(Elem));
	punt->info = elem;
	punt->prox = lista;		
	return punt;
}

void VisualizzaLista(Lista lista) {
    if (lista == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d\n ---> ", lista->info);
    	VisualizzaLista(lista->prox);
    }
}

int VerificaPresenza(Lista lista, TipoElem elem) {
	Lista cursore;
	if (lista != NULL) {
		cursore = lista;
		while (cursore != NULL) {
			if (cursore->info == elem)
				return 1;
			cursore = cursore->prox; 
		}
	}
	return 0;
}

int VerificaPresenza_ric (Lista lista, TipoElem elem) {
	if (lista == NULL)
		return 0;
	if (lista->info == elem)
		return 1;
	return VerificaPresenza_ric(lista->prox, elem);
}
