#include <stdio.h>
#include <stdlib.h>

#define N 10

typedef int TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista InsInTesta (Lista lista, TipoElem elem);
void VisualizzaLista(Lista lista);
Lista InsInOrd(Lista lista, TipoElem elem);

int main () {

	Lista lis = NULL;
	int i;
	
	for (i = N; i > 0; i--) {
		if (i != 5)
			lis = InsInTesta(lis, i);
	}
	
	VisualizzaLista(lis);
	printf("\n");	
	
	lis = InsInOrd(lis, 5);
	
	VisualizzaLista(lis);
	printf("\n");	
	
}	

Lista InsInTesta (Lista lista, TipoElem elem) {
	Lista punt;
	punt = (Lista) malloc(sizeof(Elem));
	punt->info = elem;
	punt->prox = lista;		
	return punt;
}

void VisualizzaLista(Lista lista) {
    if (lista == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d\n ---> ", lista->info);
    	VisualizzaLista(lista->prox);
    }
}

Lista InsInOrd(Lista lista, TipoElem elem) {	
	Lista punt, puntCor = lista, puntPrec = NULL;
	while (puntCor != NULL && elem > puntCor->info ) {	
		puntPrec = puntCor;
	    puntCor = puntCor->prox;
	}
	punt = (Lista) malloc(sizeof(Elem)); 
	punt->info = elem; 
	punt->prox = puntCor;
	if (puntPrec != NULL) { /* Inserimento interno alla lista */
		puntPrec->prox = punt;
	    return lista;
	} 
	else 
    	return punt; /* Inserimento in testa alla lista */
}
