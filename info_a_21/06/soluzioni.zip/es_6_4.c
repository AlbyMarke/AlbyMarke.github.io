#include <stdio.h> 
#define MAX 51

int main( ) {

	int matrix[MAX][MAX], i, j, k, lim, sum;
	
	do {   
		printf("\ndim. del quadrato ( dispari e <= %d ): ", MAX);
	    scanf("%d", &lim);
	} while ( lim > MAX || lim % 2 == 0);
	
	for (i = 0; i < lim; i++) {
		for (j = 0; j < lim; j++) { 
			matrix[i][j] = 0; 
		} 
	}
	
	i = lim - 1; 
	j = lim / 2;
	for (k = 1; k <= lim*lim; k++) {
		matrix[i][j] = k;
		if (matrix[(i+1) % lim][(j+1) % lim] == 0) {
			i = (i+1) % lim;
			j = (j+1) % lim;
		}  else
			i = (i-1+lim) % lim; //il + lim serve a gestire i numeri negativi
	}
	
	/*Visualizziamo quadrato e somma di ogni riga e colonna*/
	sum = 0;
	for (j = 0; j < lim; j++)
		sum += matrix[0][j];
		
	printf("\nIl quadrato magico di ordine %d e’:\n", lim);
	printf("\nLa somma su ogni linea e' uguale a %d.\n", sum);
	for (i = 0; i < lim; i++) {
		printf("\n");
		for (j = 0; j < lim; j++) {
			printf("%4d", matrix[i][j]);
		}
	}
	printf("\n");
}

