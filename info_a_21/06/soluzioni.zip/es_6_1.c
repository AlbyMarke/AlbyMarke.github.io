#include <stdio.h>

#define MAX 100
#define LEN_D 50
#define N_MAX 50

int main(){

	int num[N_MAX], div[LEN_D];
	int maxi = -1, n_val, i, j;
	
	do {
	
		printf("Inserire il numero di valori da considerare: ");
    	scanf("%d", &n_val);
	
	} while (n_val < 1 || n_val > N_MAX);

	// Inizializzazione divisori
	for (i = 0; i < LEN_D; i++)
    	div[i] = 0;

	for (i = 0; i < n_val; i++) {
    	
    	//Acquisizione dati
    	do {
    		printf("Inserire il %do valore: ", i+1);
    		scanf("%d", &num[i]);
    	} while (num[i] <= 0 || num[i] > MAX);

    	// Calcolo massimo
    	if (num[i] > maxi)
        	maxi = num[i];

    	//Calcolo istogramma
    	for (j = num[i] / 2; j > 1; j--)
        	if (num[i] % j == 0)
            	div[j-1]++;
	}

	for (i = 1; i < maxi / 2; i++) {
    	printf("%d\t| ", i+1);
    	for (j = 0; j < div[i]; j++)
        	printf("*");
    	printf("\n");
	}

}
