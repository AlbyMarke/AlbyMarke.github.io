#include <stdio.h>

#define MAX_LEN 100

int main() {

	int n;
	int vett[MAX_LEN];
	int i;
	int temp;

	do {
    	printf("Inserire il numero degli elementi da inserire: ");
    	scanf("%d", &n);
	} while ( n < 0 || n > MAX_LEN);

	for (i = 0; i < n; i++) {
        printf("Inserire il %do numero : ", i+1);
        scanf("%d", &vett[i]);
	}
	
	/* Inverti il vettore senza l'utilizzo di un vettore ausiliario */ 
	for (i = 0; i < n/2; i++) { 
		temp = vett[i]; 
		vett[i] = vett[n-1-i]; 
		vett[n-1-i] = temp; 
	} 
	
	/* Stampa il vettore, che ora e' invertito */ 
	for (i = 0; i < n; i++) 
		printf("%d\n", vett[i]); 
		
}
