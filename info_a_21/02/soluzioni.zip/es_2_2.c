#include <stdio.h> 
#define MAX_LEN 100
 
int main() { 

  int n;
  int dati[MAX_LEN]; 
  int i=0, j=0; 
  
  do {
    	printf("Inserire il numero degli elementi da inserire: ");
    	scanf("%d", &n);
  } while ( n < 0 || n > MAX_LEN);
  
  for (i = 0; i < n; i++) {
        printf("Inserire il %do numero : ", i+1);
        scanf("%d", &dati[i]);
  }
  
  for (i = 0; i < n; i++) 
      for(j = i+1;j < n; j++) { 
         if (dati[i] == 2 * dati[j] && i != j) { 
               printf("Coppia: %d e %d\n", dati[i], dati[j]); 
          } 
      } 
}
