#include <stdio.h>

#define MAX_LEN 100

int main() {

	int n;
	char vett[MAX_LEN];
	int i;
	int vocali = 0;
	int vocali_maiusc = 0;
	int numeri = 0;
	int esse = 0;

	do {
    	printf("Inserire il numero degli elementi da inserire: ");
    	scanf("%d", &n);
	} while ( n < 0 || n > MAX_LEN);

	// serve per scartare l'invio inserito con l'input precedente (e lasciato nel stdi
	// dalla scanf precedente
	scanf("%*c");
	
	for (i = 0; i < n; i++) {
        printf("Inserire il %do carattere : ", i+1);
        scanf("%c", &vett[i]);
        scanf("%*c");
	}
	
	for (i = 0; i < n; i++) {

		switch(vett[i]) {
		
			case 'A': case 'E': case 'I': case 'O': case 'U':
				vocali_maiusc++;
			case 'a': case 'e': case 'i': case 'o': case 'u':
				vocali++;
				break;
			case '0': case '1': case '2': case '3': case '4': case '5': case '6': 
			case '7': case '8': case '9':
				numeri++;
				break;
			case 's':
				esse++;
		}
	}
	
	printf("Numero di vocali maiuscole: %d\n", vocali_maiusc);
	printf("Numero di vocali: %d\n", vocali);
	printf("Numero di numeri: %d\n", numeri);
	printf("Numero di esse: %d\n", esse);
		
}