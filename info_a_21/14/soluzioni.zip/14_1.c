#include<stdio.h>
#include<stdlib.h>


/* Predichiarazione (il compilatore sa che poi
 verrà definita una struct Nodo_s) */
struct Nodo_s;

typedef struct Nodo_s * Albero;

typedef struct Ramo_s { 
	Albero child;  
	struct Ramo_s * next; 
} Ramo;

typedef struct Nodo_s { 
	int  dato; 
	Ramo * rami;  
} Nodo;

int main(){
	// something ...
	return 0;
}

int conta(Albero t){
	int n;
	Ramo *cur;

	if(t==NULL)
		return 0;
	else{
		n = 1;
		cur = t->rami;
		while (cur!=NULL){
			n += conta(cur->child);
			cur = cur->next;
		}
		return n;
	}
}
