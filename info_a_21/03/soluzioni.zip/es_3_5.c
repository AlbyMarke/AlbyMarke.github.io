#include<stdio.h>
#include<string.h>
#define DIM 100

int main() {
 
    char stringa[DIM];
    char traduzione[3 * DIM];
     
    int i, lunghezza, posizione = 0;
     
    printf("Inserisci la stringa:\n");
    scanf("%s", stringa);
    
    lunghezza = (int) strlen(stringa);
    
    for(i = 0; i < lunghezza; i++)
        if (stringa[i] == 'a' || stringa[i] == 'e' ||  stringa[i] == 'i' ||
            stringa[i] == 'o' || stringa[i] == 'u') {
            traduzione[posizione] = stringa[i];
            traduzione[posizione + 1] = 'f';
            traduzione[posizione + 2] = stringa[i];
            posizione = posizione + 3;
        } else {
            traduzione[posizione] = stringa[i];
            posizione++;
        }
            
    printf("La stringa tradotta è: %s\n", traduzione);
}
