#include <stdio.h>
#include <string.h>

/* Dichiarazione tipi */

typedef struct {
  char targa[7];
  char marca[15];
  char modello[20];
  int cilindrata;
  float potenza;
  char categoria[16];
} Motoveicolo;

typedef struct {
  char nome[30];
  char cognome[40];
  char codice_fiscale[16];
} Proprietario;
 
typedef struct {
  Motoveicolo motoveicolo;
  Proprietario proprietario;
} VocePRA;

typedef struct {
  VocePRA elementi[10000];
  int n_elementi;
} PRA;


int main () {
    
    /* Dichiarazione variabili */
    PRA p;
    int maxcc = 0;
    int i, j, currentcc;
    Proprietario pr;

    /* Esercizio per casa: far inserire all'utente informazioni... */
    
    /* Estrarre automobilista con l'auto di cilindrata maggiore */
    for(i = 0; i < p.n_elementi; i++){
        if(p.elementi[i].motoveicolo.cilindrata > maxcc){
            maxcc = p.elementi[i].motoveicolo.cilindrata;
            pr = p.elementi[i].proprietario;
    }
    
    /* Estrarre automobilista con la somma delle cilindrate delle sue auto maggiore */
    maxcc = 0;
    for(i = 0; i < p.n_elementi; i++){
        currentcc = 0;
        for(j = 0; j < p.n_elementi; j++){
            if (strcmp(p.elementi[i].proprietario.codice_fiscale, p.elementi[j].proprietario.codice_fiscale) == 0)
                currentcc += p.elementi[j].motoveicolo.cilindrata;
        }
        if(currentcc > maxcc){
            maxcc = currentcc;
            pr = p.elementi[i].proprietario;
        }
    }

}




