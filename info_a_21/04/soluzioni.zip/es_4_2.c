# include <stdio.h>
# define N 5
# define M 10

int main() {

	int m[N][M], i, j, cont = 0;
	int k, c, r, somma;

	printf("Inserisci %d elementi\n",N*M);

	// leggo matrice 
	for ( i = 0; i < N; i++ )
    	for ( j = 0; j < M; j++ )
        	scanf("%d", &m[i][j]);

	// conto sotto-matrici quadrate 2 x 2 a somma nulla
	for ( i = 0; i < N-1; i++ )
    	for ( j = 0; j < M-1; j++ )
        	if(m[i][j] + m[i+1][j] + m[i][j+1] + m[i+1][j+1] == 0)
        		cont++;

	printf("Le sotto-matrici quadrate 2 x 2 a somma nulla sono %d\n",cont);
   
	// conto sotto-matrici quadrate di dimensione qualsiasi a somma nulla
	cont = 0;
	for ( i = 0; i < N-1; i++ )
    	for ( j = 0; j < M-1; j++ ) {
      		for (k = 1; k+i < N && k+j < M; k++) {
      			somma = 0;
      			for (r = i; r < k+i+1; r++)
      				for (c = j; c < k+j+1; c++) {
      			  		somma += m[r][c];
      				}
      			if (somma == 0)
      				cont++;
      	 	}
      	}
      
	printf("Le sotto-matrici quadrate a somma nulla sono %d\n",cont);

}
