# include <stdio.h>
# define N 5

int main() {

    int m[N][N], i, k;

    printf("Inserisci %d elementi\n", N*N);

    // leggo matrice
    for (i = 0; i < N; i++)
        for (k = 0; k < N; k++)
            scanf("%d", &m[i][k]);

    for (k = 0; k < N/2+1; k++){
        for(i = k; i < N-k; i++)
            printf("%d ", m[k][i]);
        for(i = k+1; i < N-k; i++)
            printf("%d ", m[i][N-1-k]);
        for(i = N-2-k; i >= k; i--)
            printf("%d ", m[N-1-k][i]);
        for(i = N-2-k; i >= k+1; i--)
            printf("%d ", m[i][k]);
    }
    printf("\n");
}
