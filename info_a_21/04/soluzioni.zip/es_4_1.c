#include <stdio.h>
#define N 20
#define M 30

int main () {

	int i = 0, j = 0, k = 0, r = 0, cont = 0, vett[N] = {0}, mat1[N][M], mat2[N][M] = {0};
	
	// leggo matrice
	for (i = 0; i < N; i++)
		for(j = 0; j < M; j++)
			scanf("%d", &mat1[i][j]);
			
	// conta numeri dispari su ogni riga e popola un vettore
	for (i=0; i < N; i++) {
		for (j = 0; j < M; j++) {
			if (mat1[i][j]%2 != 0)
				cont++;
		}
		vett[i] = cont;
		cont = 0;
	}
	
	// stampa vettore
	for (i = 0; i < N; i++) {
		printf("%d ", vett[i]);
	}
	printf("\n");
			
	// riempi nuova matrice con numeri dispari senza lasciare buchi
	for (i = 0; i < N; i++) {
		for (j = 0; j < M; j++) {
			if (mat1[i][j]%2 != 0) {
				mat2[r][k] = mat1[i][j];
				k++;
				if(k==M) { k=0; r++; }
			}
		}
	}
	
	// stampa nuova matrice
	for (i = 0; i < N; i++) {
		for (j = 0; j < M; j++) {
			printf("%d ", mat2[i][j]);
		}
		printf("\n");
	}
}
