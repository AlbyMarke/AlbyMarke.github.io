#include <stdio.h>
#include <string.h>
#include <math.h>
#define N 3
#define DIM 100

int main () {
    
    // Il testo dell'esercizio assume che matrice e vettore siano dati
    int mat[N][N] = {{156, 156, 156},
                     {156, 156, 156},
                     {156, 156, 156}};
    char array[DIM] = "10011100";
    
    int i = 0, j = 0, lunghezza, valore, potenza;
    double media;
    
    // Conversione binario -> decimale
    lunghezza = (int) strlen(array);
    valore = 0;
    potenza = 1;
    for (i = lunghezza - 1; i >= 0; i--) {
        if (array[i] == '1')
            valore = valore + potenza;
        potenza = potenza * 2;
    }
    
    // Calcolo media matrice
    media = 0;
    for (i = 0; i < N; i++)
        for (j = 0; j < N; j++)
            media = media + mat[i][j];
    media = media / (N*N);
    
    printf("Valore array: %d - Valore medio matrice: %f \n", valore, media);
    
    if (valore == media)
        printf("VERO\n");
    else
        printf("FALSO\n");
}
