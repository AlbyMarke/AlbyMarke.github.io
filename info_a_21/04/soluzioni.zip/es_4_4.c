#include <stdio.h>
#define N 20
#define M 30

int main () {

    int i, j, k, r, val, trovato, mat[N][M];
    
    // Inserimento controllato
    for (i = 0; i < N; i++)
        for(j = 0; j < M; j++) {
            do {
                printf("Inserire valore [%d][%d]:\n", i, j);
                scanf("%d", &val);
                trovato = 0;
                for (k = j-1; k >= 0 && !trovato; k--)
                    if (mat[i][k] == val)
                        trovato = 1;
                for (r = i-1; r >= 0 && !trovato; r--)
                    for (k = 0; k < M && !trovato; k++)
                        if (mat[r][k] == val)
                            trovato = 1;
                if (trovato)
                    printf("Inserire un valore diverso da quelli già inseriti!\n");
                else
                    mat[i][j] = val;
            } while (trovato);
        }
            
    
    // Stampa matrice
    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
}
