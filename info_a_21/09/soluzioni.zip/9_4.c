#include <stdio.h>

// f1 calcola a elevato alla b

int f1(int a, int b){
	if (b == 0)
		return 1;
	return a * f1(a, b-1);
}

// f2 calcola la parte intera inferiore del logaritmo in base a di b
// f2 termina quando l'indice i è tale che a^(i-1) <= b e b < a^i, essendo il logaritmo in
// base a di b un numero compreso tra i-1 ed i (escluso), la sua parte intera 
// inferiore è i-1  

int f2(int a,int b){
	int i;
	for (i = 0; f1(a,i) <= b; i++);
	return i-1;
}

int main(){
	int i, a[3] = {2,3,4}, b[3] = {8,30,256};
 	for (i = 0; i<3; i++)
		printf("%d ", f2(a[i], b[i]));   
	for (i = 0; i < 3; i++)
		printf("%d ", f1(a[i], f2(a[i], b[i])));
	for (i = 0; i < 3; i++)
		printf("%d ", f2(a[i], f1(a[i], b[i])));
}

// Le ultime due cifre stampate sono -1 perché f1(a[i], b[i]) ritorna un numero che è 
// fuori dal range degli interi (perciò viene interpretato come negativo in CP2) e
// quindi il ciclo for in f2 termina subito con i=0 e viene ritornato i-1=-1 
