#include <stdio.h>
# define N 5

void f(int *a, int n);

int main(){
	int a[N] = {1,2,3,4,5};
    
	f(a,N);

	return 0;
}

void f(int *a, int n){
	
    // NOTA: la dimensione effettiva è N costante
	int i, b[N];

	if(n <= 0)
		return;
		

	for(i = 0; i < n-1; i++){
		b[i] = a[i] + a[i+1];
	}

	f(b, n-1);
	
	printf("[");
	for(i = 0; i < n; i++)
		printf("%d ", a[i]);
	printf("]\n");
	
	return;
}
