#include <stdio.h>
#include <stdlib.h>

typedef char * TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

int main () {

	Lista lis, p;
	
	/* Alloca una lista di tre elementi */
	
	// Primo elemento (testa della lista)
	lis = (Lista) malloc( sizeof(Elem) );
	lis->info = "S";
	lis->prox = NULL;
	
	// Secondo elemento (inserimento in testa)
	p = lis;
	lis = (Lista) malloc( sizeof(Elem) );
	lis->info = "LI";
	lis->prox = p;
	
	// Terzo elemento (inserimento in fondo)
	p->prox = (Lista) malloc( sizeof(Elem) );
	p->prox->info = "TA";
	p->prox->prox = NULL;
	
	/* Elimina ultimo elemento dalla lista */
	
	// Andrebbe messo: free(p->prox);
	p->prox = NULL;
	
	/* Elimina ultimo elemento dalla (nuova) lista */
	
	free(p);
	lis->prox = NULL;
	// Ora p punta ad un'area di memoria de-allocata, andrebbe: p = NULL;
	
	// Stampa LI
	while (lis != NULL) {
		printf("%s\n", lis->info);
		lis = lis->prox;
	}

}