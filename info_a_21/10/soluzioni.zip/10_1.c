#include <stdio.h>
#include <stdlib.h>

#define N 10

typedef int TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista InsInTesta (Lista lista, TipoElem elem);
int Somma(Lista lista, int M);
int Somma_rc(Lista lista, int M);

int main () {

	Lista lis = NULL;
	int i;
	
	for (i = N; i > 0; i--)
		lis = InsInTesta(lis, i);
		
	printf("Somma: %d\n", Somma(lis, 2));
	printf("Somma Ricorsiva: %d\n", Somma_rc(lis, 2));
	
}	

Lista InsInTesta (Lista lista, TipoElem elem) {
	Lista punt;
	punt = (Lista) malloc(sizeof(Elem));
	punt->info = elem;
	punt->prox = lista;		
	return punt;
}

int Somma(Lista lista, int M) {
	int sum = 0;
	if (lista == NULL)
		return -1;
	else {
		while(lista != NULL) {
			if (lista->info % M == 0)
				sum = sum + lista->info;
			lista = lista->prox;
		}
		return sum;
	}
}

int Somma_rc(Lista lista, int M) {
	if (lista == NULL)
		return -1;
	if (lista->prox == NULL) {
		if(lista->info % M == 0)
			return lista->info;
		return 0;
	}
	else {
		if(lista->info % M == 0)
			return lista->info + Somma_rc(lista->prox, M);
		else
			return Somma_rc(lista->prox, M);
	}
}
