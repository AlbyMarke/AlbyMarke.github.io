#include<stdio.h>
#include<stdlib.h>

typedef struct Node_s{
	int v;
	struct Node_s *left, *right;
}Node;
typedef Node *Tree;

Tree insert_with_duplicates(Tree, int);
int f(Tree,int);
void print_tree(Tree);
int conta(Tree, int);
int fAUX(Tree, Tree, int);

int main(){
	Tree t=NULL;

	t=insert_with_duplicates(t,12);
	t=insert_with_duplicates(t,1);
	t=insert_with_duplicates(t,12);
	t=insert_with_duplicates(t,20);
	t=insert_with_duplicates(t,21);
	t=insert_with_duplicates(t,15);

	printf("res k=2: %d, res k=3: %d\n", f(t,2), f(t,3));

	return 0;
}

Tree insert_with_duplicates(Tree t, int x){
	Tree tmp;

	if(t==NULL){
		tmp=(Tree)malloc(sizeof(Node));
		tmp->v=x;
		tmp->left=NULL;
		tmp->right=NULL;
		return tmp;
	}

	if(x < t->v){
		t->left=insert_with_duplicates(t->left,x);
	}else{
		t->right=insert_with_duplicates(t->right,x);
	}

	return t;
}

void print_tree(Tree t){
	if(t!=NULL){
		printf("%d\n", t->v);
		print_tree(t->left);
		print_tree(t->right);
	}
}

/* Conta gli elementi con valore k. */
int conta(Tree t, int k){
	if(t == NULL)
		return 0;
	if(t->v == k)
		return 1 + conta(t->left,k) + conta(t->right,k);
	return conta(t->left,k) + conta(t->right,k);
}

/* Mantengo un puntatore fisso alla radice dell'albero perché per ogni elemento voglio scorrerlo tutto. */
int fAUX(Tree head, Tree cur, int k){
	int val;

	if(cur == NULL)
		return 0;

	val = conta(head, cur->v);

	if(val == k){	
		return 1;
	}else 
		return fAUX(head,cur->left,k) || fAUX(head,cur->right,k);
}

int f(Tree t, int k){
	return fAUX(t,t,k);
}
