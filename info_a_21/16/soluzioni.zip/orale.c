//
//  main.c
//  es_orali_072109
//
//  Created by Alberto Marchesi on 10/12/21.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define LEN 10

typedef struct {
    int valore;
    char valore_txt[LEN];
    char seme[LEN];
} Carta;

typedef struct EL {
    Carta carta;
    struct EL * next;
} NodoMazzo;

typedef NodoMazzo * Mazzo;

Carta creaCarta (int valore, char valore_txt[], char seme[]);
Mazzo aggiungi (Mazzo mazzo, Carta carta);
void stampaMazzo (Mazzo mazzo);
Mazzo sostituisci (Mazzo mazzo, Carta c1, Carta c2);
Mazzo mischia (Mazzo mazzo1, Mazzo mazzo2);
int convertiSeme (char seme[]);
int confrontaCarte (Carta c1, Carta c2);
Mazzo ordina (Mazzo mazzo);
int scala (Mazzo mazzo);
int full (Mazzo mazzo);
int full_w_array (Mazzo mazzo);

int main() {
    Mazzo mazzo = NULL;
    Mazzo mazzo2 = NULL;
    Mazzo mazzo3 = NULL;
    
    mazzo = aggiungi(mazzo, creaCarta(7, "sette", "fiori"));
    mazzo = aggiungi(mazzo, creaCarta(8, "otto", "fiori"));
    mazzo = aggiungi(mazzo, creaCarta(9, "nove", "fiori"));
    mazzo = aggiungi(mazzo, creaCarta(7, "sette", "quadri"));
    mazzo = aggiungi(mazzo, creaCarta(10, "dieci", "fiori"));
    mazzo = aggiungi(mazzo, creaCarta(11, "jack", "picche"));
    mazzo = aggiungi(mazzo, creaCarta(13, "king", "cuori"));
    mazzo = aggiungi(mazzo, creaCarta(11, "jack", "fiori"));
    mazzo = aggiungi(mazzo, creaCarta(1, "asso", "picche"));
    mazzo = aggiungi(mazzo, creaCarta(7, "sette", "cuori"));
    
    stampaMazzo(mazzo);
    
    printf("Full: %d\n", full(mazzo));
    printf("Full with Array: %d\n", full_w_array(mazzo));
    printf("Scala: %d\n", full(mazzo));
    
    mazzo = ordina(mazzo);
    stampaMazzo(mazzo);
    
    mazzo = sostituisci(mazzo, creaCarta(3, "tre", "picche"), creaCarta(4, "quattro", "fiori"));
    stampaMazzo(mazzo);
    
    mazzo2 = aggiungi(mazzo2, creaCarta(1, "asso", "cuori"));
    mazzo2 = aggiungi(mazzo2, creaCarta(12, "queen", "quadri"));
    stampaMazzo(mazzo2);
    mazzo3 = mischia(mazzo, mazzo2);
    stampaMazzo(mazzo3);
}

Mazzo sostituisci (Mazzo mazzo, Carta c1, Carta c2) {
    Mazzo nuova_coda = NULL, temp, temp1;
    if (mazzo != NULL) {
        if (mazzo->next != NULL) {
            nuova_coda = mazzo->next->next;
            free(mazzo->next);
        }
        free(mazzo);
    }
    temp = (NodoMazzo*) malloc(sizeof(NodoMazzo));
    temp->carta = c2;
    temp->next = nuova_coda;
    temp1 = (NodoMazzo*) malloc(sizeof(NodoMazzo));
    temp1->carta = c1;
    temp1->next = temp;
    return temp1;
}

Mazzo mischia (Mazzo mazzo1, Mazzo mazzo2) {
    Mazzo mazzo3 = NULL;
    Mazzo cur1, cur2;
    int valore = 14, counter = 0;
    while (valore >= 2 && counter < 5) {
        cur1 = mazzo1;
        cur2 = mazzo2;
        while (cur1 != NULL & counter < 5) {
            if ((valore == 14 && cur1->carta.valore == 1) || cur1->carta.valore == valore) {
                mazzo3 = aggiungi(mazzo3, cur1->carta);
                counter++;
            }
            cur1 = cur1->next;
        }
        while (cur2 != NULL & counter < 5) {
            if ((valore == 14 && cur2->carta.valore == 1) || cur2->carta.valore == valore) {
                mazzo3 = aggiungi(mazzo3, cur2->carta);
                counter++;
            }
            cur2 = cur2->next;
        }
        valore--;
    }
    return mazzo3;
}

/*
 Ritorna: cuori -> 1; quadri -> 2; fiori -> 3; picche -> 4; tutto il resto (seme non valido) -> 5.
 */
int convertiSeme (char seme[]) {
    if (strcmp(seme, "cuori") == 0)
        return 1;
    else if (strcmp(seme, "quadri") == 0)
        return 2;
    else if (strcmp(seme, "fiori") == 0)
        return 3;
    else if (strcmp(seme, "picche") == 0)
        return 4;
    else
        return 5;
}

/*
 Ritorna 1 se c1 precede c2, -1 se c2 precede c1, 0 se sono la stessa carta.
 */
int confrontaCarte (Carta c1, Carta c2) {
    int s1, s2;
    s1 = convertiSeme(c1.seme);
    s2 = convertiSeme(c2.seme);
    if (s1 == s2) {
        if (c1.valore == c2.valore)
            return 0;
        else if (c1.valore < c2.valore)
            return 1;
        else
            return -1;
    }
    else {
        if (s1 < s2)
            return 1;
        else
            return -1;
    }
}

Mazzo ordina (Mazzo mazzo) {
    Mazzo cur = mazzo, prec = NULL, prec2, cur2, temp, temp2;
    if (mazzo == NULL)
        return mazzo;
    while (cur->next != NULL) {
        cur2 = cur->next;
        prec2 = cur;
        while (cur2 != NULL) {
            temp = cur2->next;
            if (confrontaCarte(cur->carta, cur2->carta) < 0) {
                if (prec != NULL)
                    prec->next = cur2;
                else
                    mazzo = cur2;
                if (prec2 == cur) {
                    cur->next = cur2->next;
                    cur2->next = cur;
                } else {
                    temp2 = cur->next;
                    cur->next = cur2->next;
                    prec2->next = cur;
                    cur2->next = temp2;
                }
                prec2 = cur;
                cur = cur2;
            } else
                prec2 = cur2;
            cur2 = temp;
        }
        prec = cur;
        cur = cur->next;;
    }
    return mazzo;
}

int scala (Mazzo mazzo) {
    int scala = 0, trovato;
    Mazzo cur = mazzo, cur2;
    int i;
    while (cur != NULL && !scala) {
        trovato = 1;
        for (i = 1; i <= 4 && trovato; i++) {
            cur2 = mazzo;
            trovato = 0;
            while (cur2 != NULL && !trovato) {
                if ((cur2->carta.valore == cur->carta.valore + i ||
                     (cur->carta.valore + i == 14 && cur2->carta.valore == 1)) &&
                    strcmp(cur2->carta.seme, cur->carta.seme) == 0)
                    trovato = 1;
                cur2 = cur2->next;
            }
        }
        if (i == 5 && trovato == 1)
            scala = 1;
        cur = cur->next;
    }
    return scala;
}

int full_w_array (Mazzo mazzo) {
    int coppia = 0, tris = 0;
    int counters[13] = {0};
    int i;
    while (mazzo != NULL) {
        counters[mazzo->carta.valore - 1]++;
        mazzo = mazzo->next;
    }
    for (i = 0; i < 13 && (tris == 0 || coppia == 0); i++) {
        if (tris == 0 && counters[i] >= 3)
            tris = 1;
        else if (counters[i] >= 2)
            coppia = 1;
    }
    return tris && coppia;
}

int full (Mazzo mazzo) {
    int coppia = 0, tris = 0;
    int count;
    Mazzo cur2, tris2 = NULL, tris3 = NULL;
    while (mazzo != NULL && (tris == 0 || coppia == 0)) {
        count = 1;
        cur2 = mazzo->next;
        while (cur2 != NULL) {
            if (cur2->carta.valore == mazzo->carta.valore) {
                count++;
                if (tris == 0 && count == 2)
                    tris2 = cur2;
                if (tris == 0 && count == 3)
                    tris3 = cur2;
            }
            cur2 = cur2->next;
        }
        if (tris == 0 && count >= 3)
            tris = 1;
        else if (count >= 2) {
            if (tris == 0)
                coppia = 1;
            else if (mazzo != tris2 && mazzo != tris3)
                coppia = 1;
        }
        mazzo = mazzo->next;
    }
    return tris && coppia;
}

Carta creaCarta (int valore, char valore_txt[], char seme[]) {
    Carta carta;
    carta.valore = valore;
    strcpy(carta.valore_txt, valore_txt);
    strcpy(carta.seme, seme);
    return carta;
}

Mazzo aggiungi (Mazzo mazzo, Carta carta) {
    NodoMazzo * punt = (NodoMazzo*) malloc(sizeof(NodoMazzo));
    punt->carta = carta;
    punt->next = mazzo;
    return punt;
}

void stampaMazzo (Mazzo mazzo) {
    while (mazzo != NULL) {
        printf("(%s, %s) --> ", mazzo->carta.valore_txt, mazzo->carta.seme);
        mazzo = mazzo->next;
    }
    printf("NULL\n");
}
