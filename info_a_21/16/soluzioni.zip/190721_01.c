//
//  main.c
//  es_190721_01
//
//  Created by Alberto Marchesi on 08/12/21.
//

#include <stdio.h>
#define N 10

int sottoMatriceUguale (int M[][N], int i, int j, int K);
int analizzaMatrice (int M[][N], int K, int R, int C);

int main(){
    int M[N][N] = {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 1, 1, 1, 0, 7, 7, 7, 7, 0},
        {0, 1, 1, 9, 0, 7, 7, 7, 7, 0},
        {0, 1, 9, 1, 0, 7, 7, 7, 7, 0},
        {0, 0, 2, 2, 2, 7, 7, 7, 7, 0},
        {0, 0, 2, 2, 2, 0, 0, 0, 0, 0},
        {0, 0, 2, 2, 2, 0, 0, 0, 4, 0},
        {0, 0, 6, 2, 2, 0, 1, 0, 0, 0},
        {0, 0, 5, 7, 8, 0, 0, 2, 0, 0},
        {0, 0, 2, 5, 2, 0, 0, 0, 3, 0},
    };

    //TODO: invocare la funzione
    //TODO: stampare i messaggi come da esempi
    printf("analizzaMatrice invocata su M con K=2, R=5, C=5 ritorna %d.\n", analizzaMatrice(M, 2, 5, 5));
    printf("analizzaMatrice invocata su M con K=3, R=5, C=5 ritorna %d.\n", analizzaMatrice(M, 3, 5, 5));
    printf("analizzaMatrice invocata su M con K=3, R=7, C=6 ritorna %d.\n", analizzaMatrice(M, 2, 7, 6));
    printf("analizzaMatrice invocata su M con K=4, R=7, C=6 ritorna %d.\n", analizzaMatrice(M, 4, 7, 6));
    printf("analizzaMatrice invocata su M con K=4, R=8, C=9 ritorna %d.\n", analizzaMatrice(M, 4, 8, 9));

}

int sottoMatriceUguale (int M[][N], int i, int j, int K) {
    int r, c;
    int val = M[i][j];
    for (r = i; r < i+K; r++)
        for (c = j; c < j+K; c++)
            if (M[r][c] != val)
                return 0;
    return 1;
}

int analizzaMatrice (int M[][N], int K, int R, int C) {
    int i, j;
    for (i = 0; i < R - K + 1; i++)
        for (j = 0; j < C - K + 1; j++)
            if (sottoMatriceUguale(M, i, j, K) == 1)
                return 1;
    return 0;
}
