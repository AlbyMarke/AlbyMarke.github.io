#include<stdio.h>
#include<stdlib.h>

typedef struct Node_s{
	int v;
	struct Node_s * next;
}Node;
typedef Node *Lista;

Lista ins_testa(Lista, int);
void visualizzaLista(Lista);
int listaPerDue(Lista);
int correggiLista(Lista);

int main(){

	Lista l = NULL;

	l = ins_testa(l,30);
	l = ins_testa(l,15);
	l = ins_testa(l,7);
	l = ins_testa(l,3);
	l = ins_testa(l,2);
    
    visualizzaLista(l);

	printf("Check funzioni: %d - %d\n", listaPerDue(l), correggiLista(l));
    
    visualizzaLista(l);

	return 0;
}

Lista ins_testa (Lista l, int val) {
	Lista newPtr;
	newPtr = (Lista) malloc(sizeof(Node));
	if(newPtr!=NULL){
		newPtr->v=val;
		newPtr->next=l;
	}else{
		printf("No memory available\n");
	}
	return newPtr;
}

void visualizzaLista(Lista lista) {
    if (lista == NULL)
        printf(" ---| \n");
    else {
        printf(" %d\n ---> ", lista->v);
        visualizzaLista(lista->next);
    }
}

int listaPerDue (Lista lista) {
    if (lista == NULL)
        return 1;
    if (lista->next == NULL)
        return 1;
    if (lista->next->v < 2 * lista->v)
        return 0;
    else
        return listaPerDue(lista->next);
}

int correggiLista (Lista lista) {
    int temp;
    if (lista == NULL)
        return 0;
    if (lista->next == NULL)
        return 0;
    if (lista->next->v < 2 * lista->v) {
        temp = 2 * lista->v - lista->next->v;
        lista->next->v = 2 * lista->v;
        return temp + correggiLista(lista->next);
    } else
        return correggiLista(lista->next);
}
