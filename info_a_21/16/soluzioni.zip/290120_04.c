//
//  main.c
//  es_tde
//
//  Created by Alberto Marchesi on 13/12/21.
//

#include <stdio.h>
#define LEN 1000
#define N 9

void comprimiStringa (char []);
void comprimiStringa_w_array (char []);
void decomprimiStringa (char []);

int main() {
    char stringa[LEN] = "ciiiaaaaooooo";
    comprimiStringa_w_array(stringa);
    printf("%s \n", stringa);
    decomprimiStringa(stringa);
    printf("%s \n", stringa);
}

void comprimiStringa (char stringa[]) {
    int i, j, count;
    for (i = 0; stringa[i] != '\0'; i++){
        count = 1;
        for (j = i+1; j <= i+8 && stringa[j] == stringa[i]; j++)
            count ++;
        if (count >= 2) {
            stringa[i] = count + '0';
            for (j = 2; stringa[i+count+(j-2)] != '\0'; j++)
                stringa[i+j] = stringa[i+count+(j-2)];
            stringa[i+j] = '\0';
        }
    }
}

void comprimiStringa_w_array (char stringa[]) {
    int i, j = 0, count = 1;
    int stringa_aux[LEN];
    for (i = 1; stringa[i] != '\0'; i++){
        if (stringa[i] == stringa[i-1])
            count++;
        else {
            if (count == 1) {
                stringa_aux[j] = stringa[i-1];
                j++;
            }
            else {
                stringa_aux[j] = count + '0';
                stringa_aux[j+1] = stringa[i-1];
                j = j + 2;
            }
            count = 1;
        }
    }
    if (count == 1) {
        stringa_aux[j] = stringa[i-1];
        j++;
    }
    else {
        stringa_aux[j] = count + '0';
        stringa_aux[j+1] = stringa[i-1];
        j = j + 2;
    }
    stringa_aux[j] = '\0';
    for (i = 0; stringa_aux[i] != '\0'; i++)
        stringa[i] = stringa_aux[i];
    stringa[i] = '\0';
}

void decomprimiStringa (char stringa[]) {
    int i, j = 0, k;
    int stringa_aux[LEN];
    for (i = 0; stringa[i] != '\0'; i++) {
        if (stringa[i] >= '2' && stringa[i] <= '9') {
            for (k = 1; k <= stringa[i] - '0'; k++) {
                stringa_aux[j] = stringa[i+1];
                j++;
            }
            i++;
        } else {
            stringa_aux[j] = stringa[i];
            j++;
        }
    }
    stringa_aux[j] = '\0';
    for (i = 0; stringa_aux[i] != '\0'; i++)
        stringa[i] = stringa_aux[i];
    stringa[i] = '\0';
}
