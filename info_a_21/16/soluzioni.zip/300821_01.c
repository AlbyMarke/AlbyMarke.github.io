//
//  main.c
//  es_300821_01
//
//  Created by Alberto Marchesi on 10/12/21.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// TODO: implementazione funzione
int funzione (char [], char);

int main(){
   char parola[100] = "supercalifragilistichespiralidoso";
   char target = 'a';
   int corrispondenze;

   printf("Parola iniziale:\n%s\n", parola);

   // TODO: chiamata funzione
   corrispondenze = funzione(parola, target);

   printf("Parola finale:\n%s\n", parola);
   printf("Il carattere '%c' e' stato trovato %d volte.\n", target, corrispondenze);

   return 0;
}

int funzione (char parola[], char c) {
    int i = 0, j, count = 0;
    while (parola[i] != '\0') {
        if (parola[i] == c) {
            for (j = i; parola[j] != '\0'; j++)
                parola[j] = parola[j+1];
            count++;
        } else {
            i++;
        }
    }
    return count;
}
