#include<stdio.h>
#include<stdlib.h>

typedef struct el {
    char v;
    struct el * left;
    struct el * right;
} Nodo;
typedef Nodo * Tree;

// Lista per rappresentare un percorso
typedef struct el_l {
    char v;
    struct el_l * next;
    struct el_l * prec;
} Nodo_l;
typedef Nodo_l * Lista;


int contaPalindromo(Tree);
int contaPalindromo_aux (Tree, Lista, Lista);
int percorsoPalindromo (Lista, Lista);


int main(){
    Tree t = NULL;
    
    /* Albero di esempio (con due percorsi palindromi)
                        a
                     ___|___
                    |       |
                    b       c
                 ___|   ____|____
                |      |         |
                a      d         c
                       |___   ___|
                           | |
                           b a
    */
    t = (Tree)malloc(sizeof(Nodo));
    t->v = 'a';
    t->left = (Tree)malloc(sizeof(Nodo));
    t->right = (Tree)malloc(sizeof(Nodo));
    t->left->v = 'b';
    t->left->left = (Tree)malloc(sizeof(Nodo));
    t->left->right = NULL;
    t->left->left->v = 'a';
    t->left->left->left = NULL;
    t->left->left->right = NULL;
    t->right->v = 'c';
    t->right->left = (Tree)malloc(sizeof(Nodo));
    t->right->right = (Tree)malloc(sizeof(Nodo));
    t->right->left->v = 'd';
    t->right->left->left = NULL;
    t->right->left->right = (Tree)malloc(sizeof(Nodo));
    t->right->left->right->v = 'b';
    t->right->left->right->left = NULL;
    t->right->left->right->right = NULL;
    t->right->right->v = 'c';
    t->right->right->left = (Tree)malloc(sizeof(Nodo));
    t->right->right->right = NULL;
    t->right->right->left->v = 'a';
    t->right->right->left->left = NULL;
    t->right->right->left->right = NULL;
    
    printf("Numero percorsi palidromi: %d \n", contaPalindromo(t));

}


int contaPalindromo (Tree tree) {
    if (tree == NULL)
        return 0;
    return contaPalindromo_aux(tree, NULL, NULL);
}

int contaPalindromo_aux (Tree tree, Lista path_head, Lista path_tail) {
    Lista temp;
    int cont;
    if (tree == NULL)
        return 0;
    if (path_head == NULL) {
        path_head = (Lista)malloc(sizeof(Nodo_l));
        path_head->v = tree->v;
        path_head->prec = NULL;
        path_head->next = NULL;
        path_tail = path_head;
    } else {
        temp = (Lista)malloc(sizeof(Nodo_l));
        temp->v = tree->v;
        temp->next = NULL;
        temp->prec = path_tail;
        path_tail->next = temp;
        path_tail = temp;
    }
    if (tree->left == NULL && tree->right == NULL)
        cont = percorsoPalindromo(path_head, path_tail);
    else
        cont = contaPalindromo_aux(tree->left, path_head, path_tail) + contaPalindromo_aux(tree->right, path_head, path_tail);
    temp = path_tail;
    path_tail = path_tail->prec;
    if (path_tail != NULL)
        path_tail->next = NULL;
    free(temp);
    return cont;
}

int percorsoPalindromo (Lista path_head, Lista path_tail) {
    while (path_head != NULL && path_tail != NULL) {
        if (path_head->v != path_tail->v) {
            return 0;
        }
        path_head = path_head->next;
        path_tail = path_tail->prec;
    }
    return 1;
}
