//
//  main.c
//  es_190721_02
//
//  Created by Alberto Marchesi on 08/12/21.
//

#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
    int valore;
    struct nodo* next;
} nodo;
typedef nodo* lista;

lista InsInFondo(lista lis, int elem);
void VisualizzaLista(lista lis);
lista Costruisci(void);
lista Picchi (lista lis);

int main(){
    lista lis = Costruisci();
    lista picchi = NULL;

    // TODO: visualizzazione lista input
    // TODO: invocazione funzione
    // TODO: visualizzazione lista output
    VisualizzaLista(lis);
    picchi = Picchi(lis);
    VisualizzaLista(picchi);

    return 0;
}

lista Picchi (lista lis) {
    lista prec = NULL, cur = NULL;
    lista new_lis = NULL;
    if (lis == NULL || lis->next == NULL)
        return NULL;
    cur = lis->next;
    prec = lis;
    while (cur != NULL && cur->next != NULL) {
        if (cur->valore > prec->valore && cur->valore > cur->next->valore)
            new_lis = InsInFondo(new_lis, cur->valore);
        prec = cur;
        cur = cur->next;
    }
    return new_lis;
}


lista InsInFondo(lista lis, int elem) {
    lista punt;
    if(lis == NULL){
        punt = malloc(sizeof(nodo));
        punt->next   = NULL;
        punt->valore = elem;
        return punt;
    }
    else {
        lis->next = InsInFondo(lis->next, elem);
        return lis;
    }
}


void VisualizzaLista( lista lis ) {
    if ( lis == NULL )
        printf(" ---| \n");
    else {
        printf(" %d\n ---> ", lis->valore);
        VisualizzaLista( lis->next );
    }
}

lista Costruisci(){
    // 1 -> 5 -> 16 -> 11 -> 12 -> 4 -> 5 -> 5 -> 3 -> 1 -> 5
    lista lis = NULL;
    lis = InsInFondo(lis, 1);
    lis = InsInFondo(lis, 5);
    lis = InsInFondo(lis, 16);
    lis = InsInFondo(lis, 11);
    lis = InsInFondo(lis, 12);
    lis = InsInFondo(lis, 4);
    lis = InsInFondo(lis, 5);
    lis = InsInFondo(lis, 5);
    lis = InsInFondo(lis, 3);
    lis = InsInFondo(lis, 1);
    lis = InsInFondo(lis, 5);

    return lis;
}
