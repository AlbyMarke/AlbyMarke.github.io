#include <stdio.h>
#include <stdlib.h>

#define N 10

typedef int TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista InsInTesta (Lista lista, TipoElem elem);
Elem * Max(Lista lista);

int main () {

	Lista lis = NULL;
	Elem * max;
	int i;
	
	for (i = N; i > 0; i--)
		lis = InsInTesta(lis, i);
		
	max = Max(lis);
	if (lis != NULL)
		printf("Massimo: %d\n", max->info);
	else
		printf("Lista vuota\n");
	
}	

Lista InsInTesta (Lista lista, TipoElem elem) {
	Lista punt;
	punt = (Lista) malloc(sizeof(Elem));
	punt->info = elem;
	punt->prox = lista;		
	return punt;
}

Elem * Max(Lista lista) {
	Elem * e;
	if(lista == NULL) //può accadere solo 1° chiamata 
	    return NULL;
	if(lista->prox == NULL) 
        return lista;
	e = Max(lista->prox);
	if (e->info < lista->info)
		return lista;
	else
		return e;
}
