#include <stdio.h>
#include <stdlib.h>

#define N 10

typedef int TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista InsInTesta (Lista lista, TipoElem elem);
void VisualizzaLista(Lista lista);
int Picchi(Lista lis);
int Picchi_rc(Lista lis);

int main () {

	Lista lis = NULL;
	
	lis = InsInTesta(lis, 5);
	lis = InsInTesta(lis, 11);
	lis = InsInTesta(lis, 4);
	lis = InsInTesta(lis, 9);
	lis = InsInTesta(lis, 3);
	lis = InsInTesta(lis, 5);	
	
	VisualizzaLista(lis);
	printf("\n");	
	
	printf("Numero Picchi: %d\n", Picchi(lis));	
	printf("Numero Picchi (Ricorsivo): %d\n", Picchi_rc(lis));	
	
}	

Lista InsInTesta (Lista lista, TipoElem elem) {
	Lista punt;
	punt = (Lista) malloc(sizeof(Elem));
	punt->info = elem;
	punt->prox = lista;		
	return punt;
}

void VisualizzaLista(Lista lista) {
    if (lista == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d\n ---> ", lista->info);
    	VisualizzaLista(lista->prox);
    }
}

int Picchi(Lista lis) {
	int n = 0;
	while(lis != NULL && lis->prox != NULL && lis->prox->prox != NULL){

		if(((float)(lis->info) < (float) (lis->prox->info)/2)  &&
			((float)(lis->prox->prox->info) < (float) (lis->prox->info)/2))
			n++;

		lis = lis->prox;
	}
	return n;
}

int Picchi_rc(Lista lis) {
	if( !(lis != NULL && lis->prox != NULL && lis->prox->prox != NULL) )
    	return 0;
    if(((float)(lis->info) < (float) (lis->prox->info)/2)  &&
		((float)(lis->prox->prox->info) < (float) (lis->prox->info)/2))
		return 1 + Picchi_rc(lis->prox) ;
    else
    	return Picchi(lis->prox) ;
}
