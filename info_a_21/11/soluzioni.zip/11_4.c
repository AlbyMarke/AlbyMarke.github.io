#include <stdio.h>
#include <stdlib.h>

#define N 5

typedef struct nodo {
	int n;
	struct nodo * next;
} Nodo;

typedef Nodo * Lista;

Lista ins_testa (Lista lista, int val);
void print_lista(Lista lista);
int monotona(Lista l);
int monotona_ric(Lista l);


int main () {
	Lista l=NULL;

	l=ins_testa(l,5);
	l=ins_testa(l,4);
	l=ins_testa(l,3);

	print_lista(l);
	printf("Res: %d\n",monotona_ric(l));

	l=ins_testa(l,3);
	print_lista(l);

	printf("Res: %d\n",monotona_ric(l));
	
	
	return 0;	
}	

Lista ins_testa (Lista l, int val) {
	Lista newPtr;
	newPtr = (Lista) malloc(sizeof(Nodo));
	if(newPtr!=NULL){
		newPtr->n=val;
		newPtr->next=l;
	}else{
		printf("No memory available\n");
	}
	return newPtr;
}

void print_lista(Lista l) {
    if (l == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d ---> ", l->n);
    	print_lista(l->next);
    }
}

int monotona(Lista l){
	Lista c1=l, c2;

	if(c1!=NULL)
		c2=c1->next;

	while(c2!=NULL){
		if(c2->n<=c1->n)
			return 0;
		c1=c2;
		c2=c2->next;
	}
	return 1;
}

int monotona_ric(Lista l){
	if(l==NULL || l->next==NULL){
		return 1;
	}
	if(l->n >= l->next->n)
		return 0;
	else{
		return monotona_ric(l->next);
	}
}
