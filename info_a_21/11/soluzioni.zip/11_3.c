#include <stdio.h>
#include <stdlib.h>

#define N 10

typedef int TipoElem;

typedef struct EL {
	TipoElem info;
	struct EL * prox;
} Elem;

typedef Elem * Lista;

Lista InsInTesta (Lista lista, TipoElem elem);
void VisualizzaLista(Lista lista);
void DistruggiLista(Lista lista);
Lista Reverse1(Lista lista, int keep);
Lista Reverse2(Lista lista);

int main () {

	Lista lis = NULL;
	Elem * max;
	int i;
	
	for (i = N; i > 0; i--) 
		lis = InsInTesta(lis, i);
	
	VisualizzaLista(lis);
	printf("\n");	
	
	lis = Reverse1(lis, 0);
	
	VisualizzaLista(lis);
	printf("\n");	
	
	lis = Reverse2(lis);
	
	VisualizzaLista(lis);
	printf("\n");
	
}	

Lista InsInTesta (Lista lista, TipoElem elem) {
	Lista punt;
	punt = (Lista) malloc(sizeof(Elem));
	punt->info = elem;
	punt->prox = lista;		
	return punt;
}

void VisualizzaLista(Lista lista) {
    if (lista == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d\n ---> ", lista->info);
    	VisualizzaLista(lista->prox);
    }
}

void DistruggiLista(Lista lista) {
    Lista temp;
    while(lista != NULL) {
        temp = lista->prox;
        free(lista);
        lista = temp;
	} 
}

Lista Reverse1(Lista lista, int keep) {
   Lista temp = NULL, curr = lista;
   while(curr != NULL) {
      temp = InsInTesta(temp, curr->info); 
      curr = curr->prox;
   }
   if(!keep)
      DistruggiLista(lista);
   return temp;
}

Lista Reverse2(Lista lista) {
    Lista temp, prec = NULL;
    if(lista != NULL)  {  
	  while(lista->prox != NULL) {
	     temp = prec;
	     prec = lista;
	     lista = lista->prox;
	     prec->prox = temp;
	  }
	  lista->prox = prec;
    }
    return lista;
}

Lista Reverse2_rc(Lista lista) {
     Lista p, ris;
     if (lista == NULL || lista->prox == NULL)
          return lista;
     else {
          p = lista->prox;
          ris = Reverse2_rc(p);
          p->prox = lista;
          lista->prox = NULL;
          return ris;
     }
}

