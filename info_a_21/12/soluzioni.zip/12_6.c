#include<stdio.h>
#include<stdlib.h>

typedef struct el{
	int v;
	struct el *left;
	struct el * right;
}Nodo;
typedef Nodo * Tree;

int somma(Tree);
int cercaMax(Tree);
Tree insert(Tree, int);

int main(){
	Tree t=NULL;

	t=insert(t,12);
	t=insert(t,1);
	t=insert(t,12);
	t=insert(t,20);
	t=insert(t,21);
	t=insert(t,15);

	printf("somma: %d, max val: %d\n", somma(t), cercaMax(t));

	return 0;
}

int somma(Tree t){
	if(t==NULL)
		return 0;
	return t->v + somma(t->left) + somma(t->right);
}

int max(int a, int b){
	if (a>b)
		return a;
	else
		return b;
}

int max3(int a, int b, int c){
	return max(a, max(b,c));
}

int cercaMax(Tree t){
	if(t==NULL)
		return 0;
	if(t->left==NULL && t->right==NULL)
		return t->v;
	if(t->left==NULL)
		return max(t->v, cercaMax(t->right));
	if(t->right==NULL)
		return max(t->v,cercaMax(t->left));
	return max3(cercaMax(t->right), cercaMax(t->left), t->v);
}

Tree insert(Tree t, int x){
	Tree tmp;

	if(t==NULL){
		tmp=(Tree)malloc(sizeof(Nodo));
		tmp->v=x;
		tmp->left=NULL;
		tmp->right=NULL;
		return tmp;
	}

	if(x < t->v){
		t->left=insert(t->left,x);
	}else if(x > t->v){
		t->right=insert(t->right,x);
	}

	return t;
}
