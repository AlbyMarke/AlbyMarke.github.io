#include<stdio.h>
#include<stdlib.h>

#define N 5

typedef struct nodo{
	int v;
	struct nodo *next;
}Nodo;
typedef Nodo * Lista;

Lista ins_testa(Lista, int);
void print_lista(Lista);
Lista last_bigger(Lista, int);
void ins_last_bigger(Lista, int);

int main(){
	Lista l=NULL;
	int i;

	for(i=N;i>0;i--)
		l=ins_testa(l,i);
	print_lista(l);

	ins_last_bigger(l,3);
	ins_last_bigger(l,12);
	ins_last_bigger(l,4);
	print_lista(l);


	return 0;
}

Lista ins_testa (Lista l, int val) {
	Lista newPtr;
	newPtr = (Lista) malloc(sizeof(Nodo));
	if(newPtr!=NULL){
		newPtr->v=val;
		newPtr->next=l;
	}else{
		printf("No memory available\n");
	}
	return newPtr;
}

void print_lista(Lista l) {
    if (l == NULL)
		printf(" ---| \n");
    else {
    	printf(" %d ---> ", l->v);
    	print_lista(l->next);
    }
}

Lista last_bigger(Lista l, int n){
	Lista cur=NULL;
	while(l!=NULL){
		if((l->v)>n)
			cur=l;
		l=l->next;
	}
	return cur;
}


//NB: si può restituire void in questo caso perché la testa non può cambiare
void ins_last_bigger(Lista l, int n){
	Lista temp,new_el;

	temp=last_bigger(l, n);

	if(temp!=NULL){
		new_el=(Lista) malloc(sizeof(Nodo));
		new_el->v=n;
		new_el->next=temp->next;
		temp->next=new_el;
	}
}