/*Si scriva una funzione
int f(int M[][N], int R)
che riceve in ingresso una matrice M quadrata N × N (con N costante predefinita con
l’istruzione #define N ) di interi ed un indice di riga R, e restituisce 1 se ciascun elemento della riga R è minore della somma degli elementi di ciascuna altra riga R1 di M (con R > R1), 0 altrimenti.*/
#include <stdio.h>
#define N 4

int f(int [][N], int);
int sumrow(int []);

void main(){
  int M[N][N]={{1,2,3,4},{1,1,1,2},{3,3,20,1},{19,20,20,4}};
  int r=3;

  printf("%d\n", f(M,r));
}

int f(int m[][N],int r){
  int i,j,s,res=1;
  for(i=0;i<r && res!=0;i++){
    s=sumrow(m[i]);
    for(j=0;j<N && res!=0;j++){
      if(m[r][j]>=s)
        res=0;
    }
  }
  return res;
}

int sumrow(int v[]){
  int i,tot=0;
  for(i=0;i<N;i++){
    tot=tot+v[i];
  }
  return tot;
}
