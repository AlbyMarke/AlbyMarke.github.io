/*
RGB è un modello di colori le cui specifiche sono state descritte nel 1931 dalla CIE (Commission internationale de l’éclairage). Tale modello di colori è di tipo additivo e si basa sui tre colori rosso (Red), verde (Green) e blu (Blue), da cui appunto il nome RGB.
Il colore di un pixel può quindi essere rappresentato con la seguente struttura dati:
typedef struct {int R,G,B;} colore;
Le immagini possono essere memorizzate come una matrice N × N (con N costante pre-
definita con #define N ) in cui ogni casella rappresenta la codifica RGB del colore un pixel dell’immagine.
Si scriva una funzione (e eventuali opportune funzioni ausiliarie) che riceve un’immagine e un intero K e restituisce 1 se l’immagine contiene almeno un rettangolo K × K di pixel di identico colore, 0 altrimenti.
*/
#include <stdio.h>
#define N 4

typedef struct {int R,G,B;} colore;
typedef colore immagine[N][N];

int equal(colore, colore);
int check(immagine,int);

void main(){
}

// return 1 if the two pixels are equal, 0 otherwise
int equal(colore c1, colore c2){
  if(c1.R==c2.R && c1.G==c2.G && c1.B==c2.B)
    return 1;
  return 0;
}

int check(immagine img, int k){
  int r,c,i,j;
  int found=0;

  for(r=0;r<N-k+1 && !found;r++){
    for(c=0;c<N-k+1 && !found;c++){
      found=1;
      for(i=r;i<r+k && found;i++){
        for(j=c;j<c+k && found;j++){
          if(equal(img[r][c],img[i][j])==0)
            found = 0;
        }
      }
    }
  }
  return found;
}
